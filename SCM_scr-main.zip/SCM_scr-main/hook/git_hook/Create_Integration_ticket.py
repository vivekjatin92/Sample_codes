from redminelib import Redmine
import json
import requests
import sys
import os
jsonFile =sys.argv[1]
class KAP():
    def __init__(self, api_key):
        self.url = 'https://kap.kpit.com/redmine/'
    	self.api_key= api_key
        self.kap = Redmine(url=self.url, key=self.api_key)
        self.custom_field_ids= {"K - Component Name":920,
                                "Target Branch Name":762,
                                "Git Tag":707,
                                "User Story ID":2,
                                "Ecockpit Domains":823,
				                "Git Repository Path":922,
                                "Build Variant":1250}
	
    def create_ticket_sub_function(self, json_file):
	#print(json_file)
        single_cf = list()
        infile = open(json_file)
        ini_string = infile.readlines()
        ini_string = "".join(ini_string)
        ini_string = json.dumps(ini_string)
        final_dictionary = json.loads(ini_string)
        final_dictionary = json.loads(final_dictionary)
	#print("above kap.issue.new()")
        issue = self.kap.issue.new()
	#print("below kap.issue.new()")
        issue.project_id = str(624)
        issue.tracker_id = str(111)

        issue.subject = final_dictionary['Subject']
        final_dictionary.pop('Subject')

        try:
            issue.assigned_to_id = int(final_dictionary['assigned_to'])
            final_dictionary.pop('assigned_to')
        except KeyError:
            pass
        try:
            issue.description = final_dictionary['description']
            final_dictionary.pop('description')
        except KeyError:
            pass
        try:
            issue.parent_issue_id = int(final_dictionary['parent_issue_id'])
            final_dictionary.pop('parent_issue_id')
        except KeyError:
            pass
        try:
            issue.category_id = int(final_dictionary['category_id'])
            final_dictionary.pop('category_id')
        except KeyError:
            pass
        try:
            issue.priority_id = int(final_dictionary['priority_id'])
            final_dictionary.pop('priority_id')
        except KeyError:
            pass
        try:
            issue.start_date = final_dictionary['start_date'] #  sample format 2020-10-30.
            final_dictionary.pop('start_date')
        except KeyError:
            pass
        try:
            issue.due_date = final_dictionary['due_date']
            final_dictionary.pop('due_date')
        except KeyError:
            pass
        try:
            issue.story_points = int(final_dictionary['story_points'])
            final_dictionary.pop('story_points')
        except KeyError:
            pass

        for custom_field_name in final_dictionary:
            single_cf.append({'id': int(self.custom_field_ids[custom_field_name]), 'value': final_dictionary[custom_field_name]})

        issue.custom_fields = single_cf
        created_issue = issue.save()
	#print(issue.id)
	ticket= str(issue.id)+","+str(issue.subject)
	home_dir =os.environ['HOME']
	file_path=os.path.join(home_dir, "git_hook_log", "ticket.txt")
	f=open(file_path,'w')
        f.write(str(ticket))
        f.close()
        # print(ticket)
        return

    def custom_field_details(self):
        kap_api = requests.get(url="{}projects/android-ivi-platform/issues/new".format(self.url))
	print(kap_api)
        page_txt = kap_api.text
        #print(page_txt)



k = KAP(api_key= '9b88738c4e0a4f80f027b9203b0a567f883c4b68')   #User API KEY
k.custom_field_details()
k.create_ticket_sub_function(json_file=jsonFile)
