#!/bin/bash

my_function(){

#build triggerd
echo "file changes"

}
while true; do
echo "-------Iteration Start------------"
inotifywait -e modify,create,delete,move -r /home/bms/getdata/$today.txt && my_function $start
declare -i start=1
done

# ./notifiy.sh
