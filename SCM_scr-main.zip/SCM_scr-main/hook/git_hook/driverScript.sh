#!/bin/bash
RED='\033[0;31m'
echo "<*-------------------------------------------------------------*>"
user=$(whoami) && echo -e "${RED} Your system userName: $user"
echo "$(tput setaf 1)$(tput setab 7) checking for prerequisites conditions $(tput sgr 0)"
echo -e "${RED} 1. checking for Internet access on Terminal with cmd ping 64.233.169.104 , It will take approx 10 sec"
timeout 8s ping 64.233.169.104 > $HOME/ping.txt
lineCount=$(cat $HOME/ping.txt | wc -l)
: '
if [ "$lineCount" -ge "3" ]
then
	echo "$(tput setaf 1)$(tput setab 7) Internet access : OK $(tput sgr 0)"
else
	echo "$(tput setaf 1)$(tput setab 7) Internet access : Failed: system exit $(tput sgr 0)"
	exit 1;
fi
'
echo "-----Passwordless-communication-to server----"
echo "$(tput setaf 1)$(tput setab 7)Enter password:and123$:  $(tput sgr 0)"
sudo ssh-copy-id bms@10.52.214.66
echo "$(tput setaf 1)$(tput setab 7)Connection established to Vm server: $(tput sgr 0)"
echo -e "${RED} 2. checking for local system Date with Vm server "
result=$(ssh bms@10.52.214.66 "date +%B%d")
echo "Vm server 66 date: $result"
local_result=$(date +%B%d)
echo "local machine date: $local_result"
if [[ "$result" = "$local_result" ]]
then
	echo "$(tput setaf 1)$(tput setab 7) Local system date is correct $(tput sgr 0)"
else
	echo "$(tput setaf 1)$(tput setab 7) Local system date is not correct Please SET TO CORRECT DATE i.e $result $(tput sgr 0)"
	echo -e "${RED} System exit"
	exit 1;
fi
read -p "Enter Your KPIT USERNAME: "  username
echo -e "${RED} USERNAME= $username"
mkdir -p $HOME/git_hook_log
echo $username > $HOME/git_hook_log/username.txt
echo "$(tput setaf 1)$(tput setab 7) ***** Good To Go ******* $(tput sgr 0)"
echo "<*-------------------------------------------------------------*>"

#################################to chcek python version###################################3
py_V="$(python -V 2>&1)"
version_py=$(echo "$py_V" | cut -d " " -f2)
first_py=$(echo "$version_py" | cut -d "." -f1)
second_py=$(echo "$version_py" | cut -d "." -f2)
third_py=$(echo "$version_py" | cut -d "." -f3)
if [ "$first_py" -ge "2" ]
then
        count=1
        if [ "$second_py" -ge "7" ]
        then
                count=2
                if [ "$third_py" -ge "12" ]
                then
                    count=3
                fi
        fi
else
        echo "python version leass than minimum requried version : 2.7.12 "
fi
if [ "$count" -lt "3" ]
then
	echo "$(tput setaf 1)$(tput setab 7)python version is less than 2.7.12 so we will update   $(tput sgr 0)"
	py_V_status="NotOK"
else
	echo "$(tput setaf 1)$(tput setab 7)python version: $py_V $(tput sgr 0)"

fi

############################Git-Version-check####################################################
install_git_2.9.0(){
	sudo apt-get update &&  echo -e "${RED} System update success"
	sudo apt-get install git && echo -e "${RED} Git Installed"
	 Download the Git 2.9 package from the above download link
	echo "$(tput setaf 1)$(tput setab 7)Download the Git 2.9 package from the above download link$(tput sgr 0)"
	mkdir -p $HOME/git_2.9.0
	cd $HOME/git_2.9.0
	wget https://github.com/git/git/archive/v2.9.0.zip
	unzip v2.9.0.zip
	cd git-2.9.0
	sudo  apt-get install autoconf
	sudo make configure
	sudo apt-get install gcc
	sudo ./configure --prefix=/usr/local
	sudo make prefix=/usr/local 
	if [ $? -eq 0 ] 
	then
  		 echo OK
		 sudo make prefix=/usr/local install
	else
  		sudo apt-get install zlib1g-dev
		sudo apt-get install tcl-dev
		sudo apt-get install libssl-dev
		sudo apt-get install gettext
		sudo make prefix=/usr/local 
		sudo make prefix=/usr/local install
	fi
	echo "$(tput setaf 1)$(tput setab 7)Need To reStart Machine$(tput sgr 0)"
	read -p "Enter your choice yes/no: " choice
	if [ "$choice" -eq "yes" ]
        then
                sudo reboot
        else
		echo "$(tput setaf 1)$(tput setab 7)Untill you Restart git latst version will Not appera on machine$(tput sgr 0)"        
        fi
	cd -
}

python_redmine_dependencies(){
	    #echo "$(tput setaf 1)$(tput setab 7)python version : $py_V $(tput sgr 0)"
        echo -e "${RED}Recongiguring python pip"
        sudo apt --assume-yes install python-pip  && echo "$(tput setaf 1)$(tput setab 7)Python PIP reconfigured $(tput sgr 0)"
        sudo pip install --upgrade pip  && echo "$(tput setaf 1)$(tput setab 7)Python PIP Upgraded $(tput sgr 0)"
        echo -e "${RED}Recongiguring python_redmine"
        sudo pip install python_redmine  && echo "$(tput setaf 1)$(tput setab 7)python_redmine reconfigured $(tput sgr 0)"
        echo -e "${RED}Recongiguring python_pandas" 
        sudo pip  install pandas  && echo "$(tput setaf 1)$(tput setab 7)python_pandas reconfigured $(tput sgr 0)"

}
if [ "$py_V_status" != "NotOK" ]
then
        #echo "$(tput setaf 1)$(tput setab 7)python version : $py_V $(tput sgr 0)"
        echo -e "${RED}Installing python pip"
        sudo apt --assume-yes install python-pip  && echo "$(tput setaf 1)$(tput setab 7)Python PIP Installed $(tput sgr 0)"
        sudo pip install --upgrade pip  && echo "$(tput setaf 1)$(tput setab 7)Python PIP Upgraded $(tput sgr 0)"
        echo -e "${RED}Installing python_redmine"
        sudo pip install python_redmine  && echo "$(tput setaf 1)$(tput setab 7)python_redmine Installed $(tput sgr 0)"
        echo -e "${RED}Installing python_pandas" 
        sudo pip  install pandas  && echo "$(tput setaf 1)$(tput setab 7)python_pandas Installed $(tput sgr 0)"
else
	check="ok"
    echo "$(tput setaf 1)$(tput setab 7) Installing python upgraded version  $(tput sgr 0)"
	sudo apt-get update
	sudo apt-get install build-essential checkinstall
	sudo apt-get install libreadline-gplv2-dev libncursesw5-dev libssl-dev libsqlite3-dev tk-dev libgdbm-dev libc6-dev libbz2-dev
	cd /usr/src
	wget https://www.python.org/ftp/python/2.7.18/Python-2.7.18.tgz
	sudo tar xzf Python-2.7.18.tgz
	cd Python-2.7.18
	sudo ./configure --enable-optimizations
	sudo make altinstall
	py_V="$(python -V 2>&1)"
	echo "$(tput setaf 1)$(tput setab 7)Python installed : $py_V $(tput sgr 0)"
fi

#==========================Configration===================================
cd $HOME/git_hook/
rm -rf .git/hooks
cp -r hooks .git/
echo "$(tput setaf 1)$(tput setab 7)Git-Hook Set-up $(tput sgr 0)"
mkdir -p $HOME/git_hook_log &&  echo -e "${RED}git_hook_log DIR Created at $HOME"
touch $HOME/git_hook_log/current_push_log.json
count=0
# clone DIR git_hook

git_v=$(git --version)
version=$(echo "$git_v" | cut -d " " -f3)
first=$(echo "$version" | cut -d "." -f1)
send=$(echo "$version" | cut -d "." -f2)
third=$(echo "$version" | cut -d "." -f3)
if [ "$first" -ge "2" ]
then
        count=1
        if [ "$send" -ge "9" ]
        then
                count=2
                if [ "$third" -ge "0" ]
                then
                    count=3
                fi
        fi
else
        echo "git version leass than 2.0.0 "
fi
if [ "$count" -lt "3" ]
then
	echo "$(tput setaf 1)$(tput setab 7)Git version is less than 2.9.0 so we will update  git to 2.9.* $(tput sgr 0)"
	echo -e "${RED}ref link: https://gist.github.com/YuMS/6d7639480b17523f6f01490f285da509"
	install_git_2.9.0
	echo -e "${RED}On success please restart your machine. and again run driverScript.sh"

	#echo "$(tput setaf 1)$(tput setab 7)Script FAILED due  to lower Git version  $(tput sgr 0)"
	#exit
else
	echo "$(tput setaf 1)$(tput setab 7)Git version: $git_v $(tput sgr 0)"
fi
git config --global core.hooksPath $HOME/git_hook/.git/hooks  && echo "$(tput setaf 1)$(tput setab 7)Git-Hook Set to $HOME/git_hook/.git/hooks $(tput sgr 0)"

: '
var=$(grep -i "KAP" $HOME/.bashrc)
if [ -z "$var" ]
then
	echo "alias KAP='python $HOME/git_hook/Create_Integration_ticket.py'" >> $HOME/.bashrc
	echo "$(tput setaf 1)$(tput setab 7)KAP alias added in .bashrc file $(tput sgr 0)"	
	source $HOME/.bashrc
else	
	echo "$(tput setaf 1)$(tput setab 7)KAP alias present in .bashrc file $(tput sgr 0)"
fi	
'

#echo "$(tput setaf 1)$(tput setab 7)*********DONE******** $(tput sgr 0)"


if [ "$check" = "ok" ]
then
       echo "$(tput setaf 1)$(tput setab 7)Reconfiguring python Redmine dependencies $(tput sgr 0)"
		python_redmine_dependencies 
		echo "$(tput setaf 1)$(tput setab 7)*********DONE******** $(tput sgr 0)"

else
		echo "$(tput setaf 1)$(tput setab 7)*********DONE******** $(tput sgr 0)"
fi





