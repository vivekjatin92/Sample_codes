'''
# Python script to  fetch integration tickets information from redmine and arranged output in CSV file

# python redmine_script.py
'''

from redminelib import Redmine     #sudo pip install python_redmine

import pandas as pd                #sudo pip install pandas
import os		           
'''

ticket status value for ""new": 1

'''



class Kap():   			#connectivity to redmine

    def __init__(self):

        self.url = 'https://kap.kpit.com/redmine/'

        self.api_key= '9b88738c4e0a4f80f027b9203b0a567f883c4b68' # (Amit Shinde's User API Key is used)

        self.kap = Redmine(url=self.url, key=self.api_key)

        self.status_list = [1]     # NEW status tkt





    def main_fun(self):

        mainlist=list()

        for status in self.status_list:

            for issue in self.get_all_issue(status):                #to get all ticket which are under  1  status

                mainlist.append(self.get_single_issue(issue.id))    # to get info from ticktes

        return pd.DataFrame(mainlist)



    def get_all_issue(self, status):

        return self.kap.issue.filter(project_id=624,tracker_id=111,status_id= status, assigned_to_id=1387)

			#1387 id from url for user and 624 is Digital eCockpit project ID & 111 is integration tracker Id



    def get_single_issue(self,id):

        '''

        this function is featching all the data one by one

        :param id: ticket id

        :return: returning no value

        '''

        RMData = dict()

        issue = self.kap.issue.get(id, include='journals')

        print(id)

        for cf in issue:

            if cf[0] != 'custom_fields':

                if type(cf[1]) is dict:

                    try:

                        RMData[cf[0]] = cf[1]['name']

                    except Exception as KeyError:

                        RMData[cf[0]] = ''

                else:

                    RMData[cf[0]] = cf[1]

            else:

                for eachcfs in cf[1]:

                    try:

                        RMData[eachcfs['name']] = eachcfs['value']

                    except Exception as KeyError:

                        RMData[eachcfs['name']] = None

        return RMData



k = Kap()

df= k.main_fun()

df = df.filter(items=['id','subject','User Story ID','K - Component Name','Git Tag','Git Repository Path','Target Branch Name','Ecockpit Domains','Dependencies','Build Variant'])

#df = df.filter(items=['id', 'subject', 'Android Modules', 'Feature Id', 'Git Tag','Component Information','Git Repository Path', 'Git Repository Path','Target Branch Name','Ecockpit Domains'])    #filed name list
home_dir =os.environ['HOME']
file_path=os.path.join(home_dir, "Build_System_Data", "getSheduleBuildData", "kap_ticket_data.csv")

df.to_csv(file_path, index = False)
