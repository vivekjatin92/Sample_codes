#!/bin/bash
RED='\033[0;31m'
read -p "Please Enter For Reason Deactivate (In_short): "  reason
git_repo_path=$HOME/git_hook/.git/hooks

cd $git_repo_path/

for hooks in *
do
	hook_ext=$(echo "$hooks" | cut -d "." -f2)
	hook_name=$(echo "$hooks" | cut -d "." -f1)
	if [ "$hook_ext" = "sample" ]
	then
			echo "$hooks is allredy deactivated"
	else
		withSample=$hook_name.sample
		mv $hooks $withSample && echo "rename $hooks to $withSample for deactivation"
	fi	
	
done
echo -e "${RED} Git Hook Ditactivated: To Activate again please run driverscript from $HOME/git_hook/" 
UnTrack=$(cat $HOME/git_hook_log/username.txt)
string1=$(echo "Purpose:$reason :By: $UnTrack")
today=$( date +%B%d)
result=$(ssh bms@10.52.214.66 "cd /home/bms/UnameTrack; touch $today.txt ;echo $string1 >>/home/bms/UnameTrack/$today.txt"  2>&1) 

cd -
