import re
import os
import sys
import subprocess
msg =sys.argv[1]
with open(msg, 'r') as file:
    MSG = file.read().replace('\n', '')
#print (data1)
#array=data1.split(':')
r = re.compile('[0-9]*:.*:.*:.*:.*:.*')
if r.match(MSG) is not None:
   print("git commit success")
else:
   print("commit msg not matched: please enter formatted commit msg: git commit failed!!!")
   print("format shoulb be like this:- user_story_id:component_name:Domain Name:commit_msg:Dependency (Yes/No):build variants(MCP):Commit msg")
   print ("For Ex: 123456:HVAC:HMI:Yes/No:MCP:Integrate HVAC in AOSP 10")
   sys.exit(1)
   
#https://stackoverflow.com/questions/2293498/applying-a-git-post-commit-hook-to-all-current-and-future-repos
# command  $ git config --global core.hooksPath /path/to/my/centralized/hooks
	# ex-  $ git config --global core.hooksPath /home/kpit/Desktop/git_hook/git_repo/.git/hooks   
# 1. prepare-commit-msg
# 2. pre-commit.py
# 3. post-commit / pre-push / post-push

