#!/bin/bash

##############################################################################
#  Author           : Amit Shinde.
#  FILE NAME        : error_analayser.sh
#  FILE DESCRIPTION : This script identifies aosp build errors and Performing corrective action againest errors                   
##############################################################################

msg_USAGE="$0 <repo-workspace> <failuer-process-name> <build-logfile-path>
\n\t\t<repo-workspace>        - arg1, path for repo workspace
\n\t\t<failuer-process-name>  - arg2, aosp process failuer process i.e repo/hmi/make
\n\t\t<build-logfile-path>    - arg3, Failuer build log file path"

[[ $# -lt 3 ]] && echo -e $msg_USAGE && exit 1

repo_workspace=$1
failuer_part=$2
log_file="${3:-/dev/stdin}"
SCRIPT_DIR=$(dirname $(readlink -f "$0"))
source $SCRIPT_DIR/analayser_utils.sh
declare -a flag

# Function which Identifies erros wrt repo tool
repo_tool_err_analyzer(){
     echo "Analysing repo tool eroor"
     err_arr=("repo not found" "syntax error" "contains uncommitted changes" "not a valid SHA1")
     for err in "${err_arr[@]}"; do
        if  grep -iqF "$err" $log_file; then  flag+=("$err"); fi
    done
    echo "$(tput setaf 9)Found Error wrt to::"${flag[@]}" $(tput sgr 0)"
    corrective_actions  # flag array count chcek befor aclling function
}

# Function which Identifies erros wrt HMI build
hmi_build_err_analyzer(){
     echo "Analysing hmi build  eroor"
     err_arr=("local properties file" "SDK location not found" "./gradlew: Permission denied")
     for err in "${err_arr[@]}"; do
        if  grep -iqF "$err" $log_file; then  flag+=("$err"); fi
    done
    echo "$(tput setaf 9)Found Error wrt to::"${flag[@]}" $(tput sgr 0)"
    corrective_actions
}

# Function which Identifies erros wrt aosp build (make -j24)
aosp_build_err_analyzer(){
     echo "Analysing aosp make process  eroor"
     err_arr=("MTK_PLATFORM is not defined" "_intermediates/package.apk', missing")
     for err in "${err_arr[@]}"; do
        if  grep -iF "$err" $log_file; then  flag+=("$err"); fi
    done
    echo "$(tput setaf 9)Found Error wrt to::"${flag[@]}" $(tput sgr 0)"
    corrective_actions
}

# Function to identifies corrective action wrt identified error for repo/hmi/make
corrective_actions(){
     for err in "${flag[@]}"; do
     echo "$(tput setaf 10)performaing corrective actions for :$err $(tput sgr 0)"
      case "$err" in
	  
   # Repo tools Issues
       "repo not found" | "syntax error" )
             echo "install/reinstall and pull latest repo bunddle"
             repo_not_found_err_action $repo_workspace
             ;;
       "contains uncommitted changes")
             echo "clearing Local chnages from  repo_workspace/.repo"
             repo_uncommit_chages_err_action $repo_workspace
             ;;
       "not a valid SHA1")
             echo "Wrong commit ID added in manifest..chceking"
             repo_wrong_commit_err_action $repo_workspace $SCRIPT_DIR/$log_file
             ;;
			 
  # HMI Build Issues
	"SDK location not found" | "local properties file")
             echo "HMI Build failed due Android SDK dependency not found"
             hmi_SDK_err_action $repo_workspace $SCRIPT_DIR/$log_file
             ;;
       "./gradlew: Permission denied")
             echo "HMI Build failed due gradlew permission issue"
             hmi_gradle_permission_err_action $repo_workspace $SCRIPT_DIR/$log_file
             ;;
			 
  # Make -j24 Issues
	"MTK_PLATFORM is not defined")
             echo "AOSP Build failed due MTK_PLATFORM is not defined"
             aosp_MTK_Platform_err_action $repo_workspace
             ;;
        "_intermediates/package.apk', missing")
             echo "AOSP Build failed due HMI build (apk) failuer"
             aosp_apk_missing_err_action $repo_workspace $SCRIPT_DIR/$log_file
             ;;
			 
  # Default Condition
	 *)
	     echo "No any specified Eroor found, please connect to CM team" && exit 0;
            ;;
      esac
    done
}

# Performing error analysis and correction on basis of buil failuer process
[[ "$failuer_part" == "repo" ]] && echo "failuer in :repo tool " && repo_tool_err_analyzer
[[ "$failuer_part" == "hmi" ]]  && echo "failuer in :hmi  build " && hmi_build_err_analyzer
[[ "$failuer_part" == "make" ]] && echo "failuer in :make build " && aosp_build_err_analyzer

exit 0;
