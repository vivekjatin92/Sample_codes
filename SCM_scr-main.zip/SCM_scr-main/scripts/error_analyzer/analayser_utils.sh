#!/bin/bash

##############################################################################
#  Author           : Amit Shinde.
#  FILE NAME        : analayser_utils.sh
#  FILE DESCRIPTION : This is utility script (correction action wrt build erros) used by error_analayser.sh
##############################################################################

#-------------------------------Repo-Tool-Error-corrective-action-----------------------------------#
repo_not_found_err_action(){
     #sudo apt-get update
     #sudo apt-get install repo
     #[[ $? -eq "1" ]] && echo "Not able to run sudo command " && exit 1 ;
     mkdir -p ~/bin/ && curl https://storage.googleapis.com/git-repo-downloads/repo -o ~/bin/repo
     chmod +x ~/bin/repo && repo version
     echo "PATH=~/bin:$PATH" >> ~/.bashrc && source ~/.bashrc && sync
     cd $repo_workspace/.repo/repo && git pull
     echo "$(tput setaf 10)Repo has been Intsalled successfully $(tput sgr 0)" && cd -
}

repo_uncommit_chages_err_action(){
    repo_workspace=$1
    cd $repo_workspace/.repo/manifests && pwd
    git stash && git stash clear && cd -
    git checkout aosp_mtk_hmi_ga_release && git pull
    # repo forall -c -e
    echo "$(tput setaf 10)cleared local chages .repo & perform git pull aosp_mtk_hmi_ga_release branch $(tput sgr 0)"  && cd -
}

repo_wrong_commit_err_action(){
   repo_workspace=$1
   #log_file="$2" && echo $log_file
   cmp=$(grep  -iF "not a valid SHA1" $log_file | tail -1 | awk -F ':' '{print $2,$4}')
   echo "$(tput setaf 9)repo sync failed :'$cmp': please chcek manifest $(tput sgr 0)"
   # send emial script $cmp
}

#-------------------------------HMI-build-Error-corrective-action-----------------------------------#
hmi_SDK_err_action(){
   repo_workspace=$1
   #log_file="$2"
   err_path=$(grep -iF "SDK location not found" "$log_file"  | awk -F "'" '{print $3}')
   [[ -f $err_path ]] && rm -rf $err_path
   [[ -d $HOME/Android/Sdk ]] &&  export ANDROID_HOME=$HOME/Android/Sdk
   echo "$(tput setaf 9)Cleared local.properties file and expoted Andriod SDK path $(tput sgr 0)"
   # send emial script $cmp
}

hmi_gradle_permission_err_action(){
   repo_workspace=$1
   #log_file="$2"
   err_path=$(grep -i -B 1 './gradlew: Permission denied' "$log_file" | head -n 1| awk -F ' ' '{print $4}')
   [[ -d $repo_workspace/$err_path ]] &&  chmod +x $repo_workspace/$err_path/gradlew 
   echo "$(tput setaf 9)Provided execution permission for $repo_workspace/$err_path/gradlew $(tput sgr 0)"
}

#-------------------------------AOSP-build-Error-corrective-action-----------------------------------#

aosp_MTK_Platform_err_action(){
   repo_workspace=$1
   cd $repo_workspace && echo "Starting incremental aosp build in same path @$repo_workspace"
   make -j`nproc`
}

aosp_apk_missing_err_action(){
   repo_workspace=$1
   #log_file="$2"
   err_path=$(grep -iF "_intermediates/package.apk', missing" $log_file | awk -F "'" '{print $2}')
   echo "apk missing : $err_path ## Running HMI build script"
   basepath=$(echo $repo_workspace | sed 's|\(.*\)/.*|\1|')  #Cutting all the characters after the last /
   target=$(basename $repo_workspace)                        # basename i.e target
   $SCRIPT_DIR/hmi_build.sh $basepath $target clean $SCRIPT_DIR/gradlePath.txt
   [[ $? -eq 1 ]] && echo "HMI Build failed, please connect to CM taem" && exit 1;
   cd $repo_workspace && echo "Starting incremental build in same path @$repo_workspace"
   make -j`nproc`
}
