# Author : Amit Shinde.
# python3 show_build_log.py

import flask
import time
def follow(thefile):
    thefile.seek(0,2)
    while True:
        line = thefile.readline()
        if not line:
            time.sleep(0.1)
            continue
        yield line


app = flask.Flask(__name__)

@app.route('/mtk')
def index():
    def inner():
        logfile = open("/home/vivekk/Buildlog/mtk_log.txt","r")
        loglines = follow(logfile)
        for line in loglines:
           # print (line)
            yield '%s<br/>\n' % line
    return flask.Response(inner(), mimetype='text/html')  # text/html is required for most browsers to show the partial page immediately

@app.route('/conti')
def index():
    def inner():
        logfile = open("/home/vivekk/Buildlog/conti_log.txt","r")
        loglines = follow(logfile)
        for line in loglines:
           # print (line)
            yield '%s<br/>\n' % line
    return flask.Response(inner(), mimetype='text/html')

@app.route('/pana')
def index():
    def inner():
        logfile = open("/home/vivekk/Buildlog/pana_log.txt","r")
        loglines = follow(logfile)
        for line in loglines:
           # print (line)
            yield '%s<br/>\n' % line
    return flask.Response(inner(), mimetype='text/html')

app.run(debug=True, port=5000, host='10.52.214.55')


# http://10.52.214.55:5000/mtk or w3m http://10.52.214.55:5000/mtk
# python3 -m pip install flask
# sudo apt-get install w3m
# make -j24 | tee /home/vivekk/Buildlog/mtk_log.txt
