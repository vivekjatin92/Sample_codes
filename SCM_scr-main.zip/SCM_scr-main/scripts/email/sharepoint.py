import requests
import os
from office365.runtime.auth.authentication_context import AuthenticationContext
#from office365.runtime.utilities.request_options import RequestOptions

os.system('export PYTHONWARNINGS="ignore:Unverified HTTPS request"')

import logging
logging.basicConfig()
#logger = logging.getLogger('logger')

url = "https://kpitc-my.sharepoint.com/:x:/g/personal/avinashb6_kpit_com/EUQbsHsaN59IoVqKoiTu-f4BhjQqXzLF_xG_11Gk3xuAZQ?e=4%3AptnYY9&at=9&CID=8472b4b6-dac1-2751-4c66-b9600b4c555f"

username = "amits25@kpit.com"
password = ""

ctx_auth = AuthenticationContext(url)
token = ctx_auth.acquire_token_for_user(username, password)
print(token)
#options = RequestOptions(url)
#ctx_auth.authenticate_request(options)

req = requests.get(url, verify=False, allow_redirects=True)

output = open('Build_status.xlsx', 'wb')
output.write(req.content)
output.close()

'''
sudo pip3 install Office365-REST-Python-Client
sudo pip3 install pyopenssl
sudo pip3 install pytz
sudo pip3 install requests
'''
