# KPIT Dashboard App

import subprocess
import datetime
import sqlite3
import csv
import os

from flask import Flask, render_template, request, url_for, flash, redirect
from werkzeug.exceptions import abort

servers=[]

def get_servers():
  global servers
  servers = []
  with open('servers.csv', mode='r') as csvfile:
    csv_data=csv.reader(csvfile, delimiter=';')
    headers=next(csv_data)
    #ervers=[dict(zip(headers,i)) for i in csv_data]
    servers=[dict(zip(headers,i)) for i in csv_data if not i[0].startswith("#") and os.system("ping -c 1 " + i[1] + " > /dev/null 2>&1") == 0]
    #print(servers)
    return servers

servers=get_servers()

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn


def get_post(post_id):
    conn = get_db_connection()
    post = conn.execute('SELECT * FROM posts WHERE id = ?',
                        (post_id,)).fetchone()
    conn.close()
    if post is None:
        abort(404)
    return post


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your secret key'

cw = "CW" + str(datetime.date.today().strftime("%V"))

@app.route('/')
def index():
    #conn = get_db_connection()
    #posts = conn.execute('SELECT * FROM posts').fetchall()
    #conn.close()
    servers = get_servers()
    return render_template('index.html', posts=servers, datax=datax)


def datax(id):
    server = list(filter(lambda server: server['id'] == str(id), servers))
    result = subprocess.run(['ssh', '-l', 'bms', server[0]['ipaddress'], 'df -h | grep -w /; free -h |grep -w Mem; uptime | awk -F, "{ print \$3, \$6 }"; nproc '], stdout=subprocess.PIPE)
    result = result.stdout.decode('utf-8')
    #print(result)
    return result.split()


@app.route('/tickets', methods=('GET', 'POST'))
def tickets():
    global cw
    #if request.method == 'POST':
      #if request.form['Tickets'] == 'Tickets':
    cw = request.form['calender-week']
    return render_template('tickets.html', kap_tickets=kap_open_tickets)

def kap_open_tickets():
    result = subprocess.run(['bash','/home/bms/scripts/kap_integrate.sh', cw], stdout=subprocess.PIPE)
    return result.stdout.decode('utf-8')


@app.route('/htop/<int:server_id>')
def htop(server_id):
    server = list(filter(lambda server: server['id'] == str(server_id), servers))
    #print(server[0]['ipaddress'])
    result = subprocess.run(['ssh', '-l', 'bms', server[0]['ipaddress'], 'top -bc -n1 -w 180'], stdout=subprocess.PIPE)
    result = "<html><body><pre>" + result.stdout.decode('utf-8') + "</pre></body></html>"
    #print(result)
    return result


@app.route('/last/<int:server_id>')
def last(server_id):
    server = list(filter(lambda server: server['id'] == str(server_id), servers))
    result = subprocess.run(['ssh', '-l', 'bms', server[0]['ipaddress'], '/usr/bin/last -adFw'], stdout=subprocess.PIPE)
    result = "<html><body><pre>" + result.stdout.decode('utf-8') + "</pre></body></html>"
    return result


@app.route('/<int:post_id>')
def post(post_id):
    #post = get_post(post_id)
    return render_template('post.html', post=post)


@app.route('/create', methods=('GET', 'POST'))
def create():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']

        if not title:
            flash('Title is required!')
        else:
            #conn = get_db_connection()
            #conn.execute('INSERT INTO posts (title, content) VALUES (?, ?)',
            #             (title, content))
            #conn.commit()
            #conn.close()
            return redirect(url_for('index'))

    return render_template('create.html')


@app.route('/<int:id>/edit', methods=('GET', 'POST'))
def edit(id):
    post = get_post(id)

    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']

        if not title:
            flash('Title is required!')
        else:
            #conn = get_db_connection()
            #conn.execute('UPDATE posts SET title = ?, content = ?'
            #             ' WHERE id = ?',
            #             (title, content, id))
            #conn.commit()
            #conn.close()
            return redirect(url_for('index'))

    return render_template('edit.html', post=post)


@app.route('/<int:id>/delete', methods=('POST',))
def delete(id):
    #post = get_post(id)
    #conn = get_db_connection()
    #conn.execute('DELETE FROM posts WHERE id = ?', (id,))
    #conn.commit()
    #conn.close()
    flash('"{}" was successfully deleted!'.format(post['title']))
    return redirect(url_for('index'))



