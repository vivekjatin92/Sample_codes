FLASK_ENV=development flask run --host=10.52.214.120

