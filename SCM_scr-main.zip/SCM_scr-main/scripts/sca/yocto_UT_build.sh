
#!/bin/bash

##############################################################################
#  Author           : Amit Shinde.
#  FILE NAME        : build_ut.sh
#  FILE DESCRIPTION : This script will build UT [yocto] and start quemu and
#                     execute the unittest cases to genrate xml report
##############################################################################


repo_workspace=$1
basepath="/kpit/yocto/unittest" 
rootfs_DIR="$basepath/dom0-rootfs"   # rootfs path
# rootfs_home="$rootfs_DIR/home/root"

SCRIPT_DIR=$(dirname $(readlink -f "$0"))

build_ut_yocto(){
	cd $repo_workspace
      #	yocto_meta_layers_pull $repo_workspace $target_branch
	source ./meta/poky/oe-init-build-env build
	bitbake konfluence-dom0-test-image || exit 1;
	bitbake konfluence-dom0-test-image  -c populate_sdk || exit 1;
}

build_ut_yocto

cd $basepath && pwd

# setup target build tool chain
echo "source Oe file"
source environment-setup-aarch64-poky-linux

rm -rf $basepath/dom0-rootfs/*
rm -rf konfluence-dom0-test-image-auto2712p1v1-tiny.tar.bz2
rm -rf $basepath/dom0-rootfs.pseudo_state

# install ut-pdk (sysroot)
$repo_workspace/build/tmp/deploy/sdk/kivi-tiny-glibc-x86_64-konfluence-dom0-test-image-aarch64-toolchain-2.4.4.sh  -y -d $basepath/

ln -s $repo_workspace/build/tmp/deploy/images/auto2712p1v1-tiny/konfluence-dom0-test-image-auto2712p1v1-tiny.tar.bz2

runqemu-extract-sdk konfluence-dom0-test-image-auto2712p1v1-tiny.tar.bz2  dom0-rootfs


# tmp requried
#cp -r  $SCRIPT_DIR/TEST_MAPPING/runTests  $rootfs_DIR/usr/bin
cp -r $SCRIPT_DIR/run_ut.sh  $rootfs_DIR/home/root/
cp -r $SCRIPT_DIR/TEST_MAPPING/ $rootfs_DIR/home/root/

# run quem on target rootfs, using config
cd  $basepath

sed -i '14 i /etc/init.d/sshd start &'  "$rootfs_DIR/etc/runit/1"
sed -i 's|/usr/bin/kivi_service_manager /dev/kbinder|/usr/bin/kivi_service_manager /dev/binder|g' "$rootfs_DIR/etc/runit/1"
# temp.. addition  

existing_screen=$(screen -list | grep -w "qemu_ut" | awk '{print $1}')
if [ ! -z $existing_screen ];then  screen -X -S $existing_screen quit; fi
screen -S qemu_ut -d -m -c /dev/null -- bash -c 'source environment-setup-aarch64-poky-linux;runqemu dom0-image-qemuarm64.qemuboot.conf dom0-rootfs;/etc/init.d/sshd start; exec $SHELL'

echo "sleep for 3 min"
sleep 2m

rm $HOME/.ssh/known_hosts
qemu=$(ssh -o StrictHostKeyChecking=no root@192.168.7.2 "cd /home/root/TEST_MAPPING; ../run_ut.sh;")
echo $qemu
# clear known_host entried for qemu ====@@@
#qemu=$(ssh root@192.168.7.2 "cd /home/root/TEST_MAPPING; ../run_ut.sh;")
#echo $qemu

screen -X -S qemu_ut quit;
exit 0;
