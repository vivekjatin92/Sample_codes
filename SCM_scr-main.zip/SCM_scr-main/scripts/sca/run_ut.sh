#!/bin/sh

# run inside TEST_MAPPING/ folder
for file in $(ls *.TEST_MAPPING); do
  component=${file%.TEST_MAPPING} # && echo $component
  sed -e 's,$, --gtest_output=xml:'"$component"'.xml,' $file > $component.sh
  source $component.sh 
done
