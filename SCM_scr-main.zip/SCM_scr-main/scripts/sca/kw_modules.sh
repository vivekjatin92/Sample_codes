#! /bin/bash
# Vivek K - First version of script to take CSV file for updating the Kw project
#
# TODO -
#  2. include yocto specific code creation
#  3. create multi repository logic
#  4. fail on incorrect  parameters

#set -x

project="${1:-vivek}"
module_file="${2:-ecockpit_modules.csv}"
action="${3:-list}"

user="bms"
server="http://10.52.214.120:8082"

[[ $action == "list" ]] && curl --data "action=modules&user=$user&project=$project" $server/review/api && exit 0

[ ! -f $module_file ] && echo "error: File '$module_file' not found" && exit 1

cat $module_file |
while read line
do
    module=`echo $line| awk -F "," '{print $1}' | tr -d '\n'`
    aosp=`echo $line| awk -F "," '{print $6}' | tr -d '\n'`
    #path=`echo $line | awk -F "," '{print $8}' | tr -d '\n'`
    path=$(grep "$module" $module_file | awk -F, '$8 !~ /^$/ && $3 ~ /Yes/ {print "**/"$8"/**,"}'| tr -d '\n' )

    [[ -z $module ]] || [[ -z $path ]] && continue
    module="${module// /_}" && path="${path::-1}"
    [[ $module == $prev_module ]] && continue
    prev_module=$module

    echo "$action module: $module, path: $path, for project '$project' on $server"
    [[ $action == "debug"  ]] && continue
    [[ $action == "create" ]] && [[ "$aosp" =~ "Yes" ]] && curl --data "action=create_module&user=$user&project=$project&name=$module&allow_all=true&paths=$path" $server/review/api
    [[ $action == "update" ]] && [[ "$aosp" =~ "Yes" ]] && curl --data "action=update_module&user=$user&project=$project&name=$module&new_name=$module&allow_all=true&paths=$path" $server/review/api
    [[ $action == "delete" ]] && curl --data "action=delete_module&user=$user&project=$project&name=$module" $server/review/api
done
exit 0

