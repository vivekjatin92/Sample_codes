#!/bin/bash

##############################################################################
#  Author           : Amit Shinde.
#  FILE NAME        : build_ut.sh
#  FILE DESCRIPTION : This script will build UT [yocto] and start quemu and 
#                     execute the unittest cases to genrate xml report
##############################################################################



basepath=$1    #downloads path
rootfs_DIR="/kpit/yocto/unittest/cluster-rootfs"   # rootfs path
rootfs_home="$rootfs_DIR/home/root"
repo_workspace="/kpit/yocto/conti"

cd $basepath && pwd


rm -rf $basepath/cluster-rootfs/*
# install ut-pdk (sysroot)
$repo_workspace/build/tmp/deploy/sdk/kivi-tiny-glibc-x86_64-konfluence-cluster-image-aarch64-toolchain-2.4.4.sh -y -d $basepath/

# setup target build tool chain
echo "source Oe file"
source environment-setup-aarch64-poky-linux  

# link target root image
ln -s $repo_workspace/build/tmp/deploy/images/auto2712p1v1-tiny/konfluence-cluster-image-auto2712p1v1-tiny.tar.bz2

# deleted cluster-rootfs.pseudo_state/ from basepath
rm -rf $basepath/cluster-rootfs.pseudo_state

# extract target root image to target rootfs
runqemu-extract-sdk konfluence-cluster-image-auto2712p1v1-tiny.tar.bz2 cluster-rootfs


# make build for individual components
cd $basepath/downloads  && pwd

for repo in $(ls -d */)  # for all repos
 do 
    componunt=$(echo ${repo%%/})
    echo "-----------$componunt------------"
    mkdir -p $componunt/build
    cd $componunt/build/ && pwd
    cmake ../ -DWITH_TESTS=1
    make
    if [ $? -eq 1 ]; then  echo "make failed for $repo"; continue; fi
	
    mkdir -p $rootfs_home/$componunt/build && pwd
    cp -r * $rootfs_home/$componunt/build/ 	
    # copy all *.so files
    cp $(find . -type f | grep -v ".dir" | grep -v cmake | grep -v marks | grep -v Make | grep -i ".so")  $rootfs_DIR/usr/lib
    # copy all binary files
    cp $(find . -type f | grep -v ".dir" | grep -v cmake | grep -v marks | grep -v Make | grep -v ".h" | grep -v ".so") $rootfs_DIR/usr/bin
    # copy all *.h files
    cp $(find . -type f | grep -v ".dir" | grep -v cmake | grep -v marks | grep -v Make | grep -i ".h") $rootfs_DIR/usr/include
    cd $basepath/downloads 
 done

cd  $basepath
# run quem on target rootfs, using config
#runqemu cluster-image-qemuarm64.qemuboot.conf cluster-rootfs

existing_screen=$(screen -list | grep -w "quemu" | awk '{print $1}')
if [ ! -z $existing_screen ];then  screen -X -S $existing_screen quit; fi
screen -S quemu -d -m -c /dev/null -- bash -c 'source environment-setup-aarch64-poky-linux;runqemu cluster-image-qemuarm64.qemuboot.conf cluster-rootfs;/etc/init.d/sshd start; exec $SHELL'

#quemu=$(ssh root@192.168.7.2 "cd /home/root/kvdacs/build/test;./runTests --gtest_output=xml:test.xml ;exit")
quemu=$(ssh root@192.168.7.2 "cd /home/root/; for repo in $(ls -d */); do ./${repo%%/}/build/test/runTests --gtest_output=xml:{repo%%/}.xml;done; exit;")
#echo $quemu
screen -X -S quemu quit;
exit 0;
