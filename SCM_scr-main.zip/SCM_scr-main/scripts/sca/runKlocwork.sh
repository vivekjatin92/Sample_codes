#!/bin/bash
############################################################
# Author : Amit Shinde
# Desc   : Run Klockwork Build
#############################################################

repo_workspace="/kpit/aosp/sca"
out_path="/kpit/aosp/sca"
target="conti"
SCRIPT_DIR=$(dirname $(readlink -f "$0"))
kwserver="10.52.214.120"   #$(hostname -I | awk -F" " '{print $1}')
source $SCRIPT_DIR/../build.config $target
source $SCRIPT_DIR/../build_utils.sh

promt_check(){
process="$1"
read -t10 -p  "Do you to execute $process ?:-" ans
: "${ans:=y}"
if [ $ans = "Y" ] || [ $ans = "y" ]; then  echo 1; else echo 0;  fi
}

exec_time() {
    stage=$1
    end_time=$(date +%s)
    secs=$((end_time - start_time))
    exectime=$(printf '%dh:%dm:%ds\n' $((secs/3600)) $((secs%3600/60)) $((secs%60)))
    echo "$stage, $exectime" >> /kpit/klockwork.log
  }


repo_sync(){
   cd $repo_workspace && pwd
#   rm -rf *   # tmp  aded this line
   repo init $repo_option
   repo sync  -j12
   ./device/mediatek/patch/apply_patches.sh
   $SCRIPT_DIR/hmi_build.sh /kpit/aosp  sca  clean  $SCRIPT_DIR/gradlePath.txt
}

if [ "$(promt_check "repo-sync-hmi")" = "1" ]; then  repo_sync; fi

start_time=$(date +%s)
echo `date` >> /kpit/klockwork.log

echo started building code
if [ "$(promt_check "genrate-kwinject.out")" = "1" ]; then  $HOME/Klockwork/klocwork_server/kwserver/bin/kwandroid -q --output $out_path/kwinject.out --android /kpit/aosp/sca/out --script $SCRIPT_DIR/compile.sh ; fi

exec_time "kwandroid"
echo .out file creation complete

if [ "$(promt_check "skip-external-system-out")" = "1" ]; then
    python $HOME/klocwork/kwtrimbuildpec.py -b $out_path/kwinject.out -p '**external/**'
    python $HOME/klocwork/kwtrimbuildpec.py -b $out_path/kwinject.out -p '**system/**'
    python $HOME/klocwork/kwtrimbuildpec.py -b $out_path/kwinject.out -p '**out/**'
    exec_time "kwtrimbuildpec";
fi

#Klocwork server analysis
echo starting klocwork analysis
if [ "$(promt_check "klocwork-analysis")" = "1" ]; then  $HOME/Klockwork/klocwork_server/kwserver/bin/kwbuildproject --url http://$kwserver:8082/new-sca -o $out_path/kwtables  -j 24  --add-compiler-options --timeout=300 --force  $out_path/kwinject.out; fi

exec_time "kwbuildproject"
echo klocwork analysis complete

#publish klocwork data on KW server
echo publishing klocwork data
if [ "$(promt_check "publishing-klocwork-data")" = "1" ]; then  $HOME/Klockwork/klocwork_server/kwserver/bin/kwadmin --url http://$kwserver:8082 load new-sca  $out_path/kwtables ;fi

exec_time "kwadmin"
echo process complete
#rm -rf $out_path/*
