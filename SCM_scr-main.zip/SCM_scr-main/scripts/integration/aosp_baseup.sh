#!/bin/bash

################################################################################################
# Author  : Amit Shinde
# Desc    : Script will do basup wrt lastest mediatek build and push chnages with build no tag"
################################################################################################

msg_WRONG_TARGET="Wrong target specified.  Please select 'conti', 'pana'  wrt to 'mediatek' as option\n"
msg_USAGE="$0    <target> <gerrit-username> 
\n\t\t<target>             - arg1, baseUp target wrt mediatek
\n\t\t<gerrit-username>    - arg2  gerrit username to clone manifest repo "

# Dont start build without arguments
[ $# -lt 2 ] && echo -e $msg_USAGE && exit 1

target=$1
user=$2

[[ $target != "conti" ]] && [[ $target != "pana" ]] &&  echo -e $msg_WRONG_TARGET && exit 1

SCRIPT_DIR=$(dirname $(readlink -f "$0"))
source $SCRIPT_DIR/kDit.config 
source $SCRIPT_DIR/kDit_utils.sh
mediatek_manifest="hmi_mtk_manifest_ga_release.xml"    # for now
baseup_DIR="$SCRIPT_DIR/baseup"
base_branch="konfluence_dev"

echo "Cloning omapmanifest inside $baseup_DIR"
  mkdir -p $baseup_DIR && cd $baseup_DIR  && rm -rf *
  git clone ssh://$user@hjph3androidivi.kpit.com:29418/platform/omapmanifest 
  [[ ! -d $baseup_DIR/omapmanifest ]] && echo "Git clone failed, $baseup_DIR/omapmanifest does't exit " && exit 1
  cd omapmanifest/ &&   git checkout $base_branch        # checkout on build branch
  mtk_latest_tag=$(git tag --sort=committerdate | grep M | tail -1)
  echo "HEAD attached to git tag $mtk_latest_tag"
  git checkout $mtk_latest_tag || exit 1;
  target_manifest_path="$baseup_DIR/omapmanifest/$manifest_name"

echo " Collecting Diff btween mediatek and $target inside $baseup_DIR/delta.txt "
  git diff -U0  --no-index $manifest_name $mediatek_manifest > $baseup_DIR/delta.txt
  sed -i '/platform\/build/d' $baseup_DIR/delta.txt     # removing 'platform/build' project node form delta.txt"
  cd $baseup_DIR
  printf "<?xml version=\"1.0\"?> \n <manifest>" > delta.xml
  grep -w "+" delta.txt | cut -d "+" -f2 >> delta.xml
  printf "\n </manifest>" >> delta.xml
  rm delta.txt

  projects=$(xmllint --xpath 'mainifest/project/@name|/manifest/project' delta.xml)
  IFS='>' read -a entries <<< "$projects"
  #echo "${projects}"

echo " Initilized repo_skip array wrt $target "
  repo_skip_pana=("android-car/device/mediatek/mt2712 android-car/device/mediatek_projects platform/build platform/hardware/interfaces vendor/mediatek/mt2712/modules")
  repo_skip_conti=("android-car/device/mediatek/mt2712 android-car/device/mediatek/patch android-car/device/mediatek_projects android-car/kernel-4.19 android-car/src/bsp/lk kernel/configs platform/build platform/frameworks/av platform/packages/apps/Car/Settings platform/packages/services/Car platform/system/core vendor/mediatek/mt2712/modules konfluence/konfluence_vehicle_gateway.git vendor/continental/modules device/continental/iip_entry_dgt vendor/kpit/packages/services/konfluence_map_service platform/system/sepolicy android-car/meta/meta-mediatek-azalea")

 [[ $target == "pana" ]] && repo_skip=$repo_skip_pana
 [[ $target == "conti" ]] && repo_skip=$repo_skip_conti

echo "_________attachment of head to latest commit___________________"
   cd $baseup_DIR/omapmanifest && pwd
   git checkout $base_branch
   git pull origin $base_branch && cd -
echo "__________ HEAD Detached to latest commit________________________"

for entry in "${entries[@]}"
do
    project_node="$entry>"
    #echo $project_node >>  $baseup_DIR/before_skip.txt
    echo "$project_node" >  project.tmp
    name_attr=$(xmllint --xpath 'project/@name' project.tmp)
    name=$(echo $name_attr | sed -r 's/^name="(.*)"$/\1/g')
    if [[ ! "$repo_skip" == *"$name"* ]]; then
      # Process the record
      lineno=`grep -nw "$name\"" $target_manifest_path | awk -F":" '{print $1 }'`"s"
      if [[ ! -z "$lineno" ]] &&  [[ $lineno =~ [0-9] ]]; then 
         sed -i -r "$lineno#.*#$project_node#g" $target_manifest_path
      else
          echo "Please chcek $name is may be new coponunt to Integarte in $target"
      fi
      #echo $project_node >> $baseup_DIR/after_skip.txt
    fi
done
rm project.tmp delta.*

git_push_opertion(){
   cd $baseup_DIR/omapmanifest
#   head_tag=$(git lola | grep -w -m 1 "MEDIATEK" |  cut -d ':' -f2 | cut -d ")" -f1 )
#   [[ ! $head_tag == *CW* ]] && head_tag=$(git lola | grep -w -m 1 "MEDIATEK" | awk '{print $2}')
   target_cap=$(echo $target | tr '[a-z]' '[A-Z]')
   commit_msg="$target_cap : baseup wrt latest mediatek [$mtk_latest_tag]"
   echo "changes done in : $manifest_name ## on branch : $base_branch ## will be push with commit msg : $commit_msg"
#   exit 0;
   git add $manifest_name
   git commit -m "$commit_msg"
   git push origin $base_branch
   #rm -rf $baseup_DIR
}
git_tag_operation(){
     cd $baseup_DIR/omapmanifest && git pull
     build_no=$(Build_No $target aosp increment) && echo $build_no
     git tag $build_no
     git push origin $build_no
     rm -rf $baseup_DIR
  }

# temporey code
echo "Check  git diff o/p for baseup "
cd $baseup_DIR/omapmanifest
git diff 
echo "#######################################################################################"

read -p "Do you want you push baseup changes to omapmanifest?:- " yn
    case $yn in
        [Yy]* ) 
             echo "calling git push fun" 
              git_push_opertion
              git_tag_operation
            ;; 

        [Nn]* ) echo "Base up changes will keep as local, not pushed " && exit 0;;
        * ) echo "Please answer yes or no. or (y/n)";;
    esac

# rm -rf $baseup_DIR
exit 0;
