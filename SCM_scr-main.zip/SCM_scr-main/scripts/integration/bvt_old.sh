#!/bin/bash

build_no=$1            # arg1: which is genrated from previpus stage (build-deploy) from gitlab.
konfluence_branch=$2   # arg2: gitlab branch.
apache_path="/zen/kivi_android/Sdk"
BVT_file_path="$apache_path/$build_no/$build_no.bvt"
apache_url="http://10.52.214.55/kivi_android/Sdk/$build_no/$build_no.bvt"
konfluence_ci_path="/home/vivekk/tmp/kamal/test/konfluence_ci"  # taken tmp path for now

if [ ! -f "$BVT_file_path" ]; then echo "File Not found @ $BVT_file_path" ;exit 1; fi
bvt_status=$(cat $BVT_file_path | head -n 1)

cd $konfluence_ci_path && pwd   # git operations
git checkout $konfluence_branch && git pull
sed -i '$i'"$(echo '|'$build_no' |'$bvt_status' | ['$build_no'.bvt]('$apache_url')|')" README.md  # append at 2nd last line
git commit -am "[ci skip] Upadted README.md file wrt Build[$build_no] details"
git push origin $konfluence_branch

# For Gitlab stage status
if [ "$bvt_status" == "PASS" ]; then echo "BVT PASS";exit 0; else echo "BVT fail" && exit 1; fi

