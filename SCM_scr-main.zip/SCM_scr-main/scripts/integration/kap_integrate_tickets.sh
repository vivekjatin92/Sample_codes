#/bin/bash
# sample curl call
# curl -s -H "Content-Type: application/xml"  GET -H "X-Redmine-API-Key: f8eb2308099c777634ddd9a227afd878c9ace955" \
#           'https://kap.kpit.com/redmine/issues.xml?parent_id=760110&status_id=2' > $kap_output
#
# ToDo
# Command line parameter check
# check for empty tickets

curr_week="${1:-CW$(date '+%U')}" # get current week to check for both weeks of sprint i.e. CW07 & CW08
kap_output="kap_output.xml"

echo Fetching User stories for $curr_week

curl -s -H "Content-Type: application/xml"  GET -H "X-Redmine-API-Key: f8eb2308099c777634ddd9a227afd878c9ace955" \
           'https://kap.kpit.com/redmine/issues.xml?parent_id=760110&status_id!=2&tracker_id=6&subject=~'$curr_week > $kap_output

userstory_ids=$(grep -Po '<id>\K([0-9]+)' $kap_output)
echo -e $userstory_ids"\n"

for userstory_id in $userstory_ids; do

  curl -s -H "Content-Type: application/xml"  GET -H "X-Redmine-API-Key: f8eb2308099c777634ddd9a227afd878c9ace955" \
             'https://kap.kpit.com/redmine/issues.xml?parent_id='$userstory_id > $userstory_id.xml

  [[ ! -f $userstory_id.xml ]] && continue
  [[ $(stat -c %s $userstory_id.xml) == 100 ]] && rm $userstory_id.xml && continue 

  xmlstarlet sel -t -m '//issues/issue[id="'$userstory_id'"]' -o 'User story "' -v 'id' -o '" - '  -v 'subject'  $kap_output
  echo -e "\n-----------------------------------------------------"
  #xmlstarlet sel -t -v "//issues/issue/subject" -v "//issues/issue/status"  $userstory_id.xml

  xmlstarlet sel -t -m '//issues/issue/status[@id!=3]/..' -v 'id' -o ',' -v 'status/@name' -o ',' -v 'assigned_to/@name' -o ',' -v 'subject' -n $userstory_id.xml
  # category/@name, fixed_version/@name, author/@name

  echo -e "\n"
  rm $userstory_id.xml

done

rm $kap_output
exit 0


