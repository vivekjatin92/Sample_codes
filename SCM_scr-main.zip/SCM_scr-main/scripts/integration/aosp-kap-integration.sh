#!/bin/bash

#############################################################################
#Author: Amit Shinde.

#Script to replace the component[revision & upstream] autometically in Manifest and file
# And push those changes in manifest repo with propere commit message

#############################################################################
basepath=$1
target=$2
SCRIPT_DIR=$(git rev-parse --show-toplevel)
csvFilePath=$SCRIPT_DIR/integration/aosp_kap_ticket_data.csv    #csv file path as argv 2
source $SCRIPT_DIR/kDit.config

empty_check=$(cat $csvFilePath | wc | awk '{print $2}')
if [ "$empty_check" == "0" ]; then echo "No new ticket build :: will not triggerd"; exit 0; fi

# manifest clone
mkdir -p $basepath/baseup && cd  $basepath/baseup  && rm -rf *
  git clone ssh://admin@hjph3androidivi.kpit.com:29418/platform/omapmanifest
  [[ ! -d  $SCRIPT_DIR/baseup/omapmanifest ]] && echo "Git clone failed, $baseup_DIR/omapmanifest does't exit " && exit 1
  manifest_path="$basepath/baseup/omapmanifest/$manifest_name"
  cd  $SCRIPT_DIR/baseup/omapmanifest  
  git checkout konfluence_dev        # checkout on build branch
  echo $manifest_path


sed -i '1d' $csvFilePath && echo " Removed Header line form  $csvFilePath"
cat $csvFilePath |
while read line
do
	echo "================================================================================"
	taskID=`echo $line | awk -F"," '{print $1}'`          # task ID
	cmpName=`echo $line | awk -F"," '{print $4}'`         #cmp Name/Path
	cmpCommit=`echo $line | awk -F"," '{print $5}'`       # cmp Commit
	cmpBranch=`echo $line | awk -F"," '{print $6}'`       # cmp Branch
      	
	line_NO=$(cat $manifest_path | grep -nw "$cmpName" | awk -F":" '{print $1}')
        echo " Task : $taskID # line No: $line_NO # cpmName : $cmpName # CommitID: $cmpCommit # Branch: $cmpBranch"
	oldRevision=$(xmllint --xpath '(//project[@path="'$cmpName'"]/@revision)' $manifest_path)
        oldUpstream=$(xmllint --xpath '(//manifest/project[@path="'$cmpName'"]/@upstream)' $manifest_path)
	
        echo "$oldRevision ### $oldUpstream"	
        newRevision=" revision=\"$cmpCommit\"";
	newUpstream=" upstream=\"$cmpBranch\"";  
	
	sed -i "${line_NO} s/${oldRevision}/${newRevision}/g" $manifest_path  && echo "Updated Revision to : '$newRevision' "
	sed -i "${line_NO} s/${oldUpstream}/${newUpstream}/g" $manifest_path && echo "Updated Upstream to : '$newUpstream' "
done 

git_push_opertion(){
   TaskID=$(cat $csvFilePath | awk -F"," 'BEGIN { OFS = " "} { printf $1 " " }')
   cd $basepath/baseup/omapmanifest
   git_commit_msg="${target^^} : Integarted task $TaskID" && echo $git_commit_msg
   git add $manifest_name
   git commit -m "$git_commit_msg"
   git push origin konfluence_dev
   echo "Perfromimg GIt rebase"
   git checkout aosp_mtk_hmi_ga_release
   git pull
   git rebase konfluence_dev
   git push origin aosp_mtk_hmi_ga_release
}
git_push_opertion 

cd $SCRIPT_DIR/integration/  && rm -rf baseup/
rm -rf $csvFilePath
exit 0;
