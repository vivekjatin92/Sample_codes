#!/bin/bash

######################################################################################
# Author     :  Amit Shinde
# Desc       :  Script will do baseup/baseline for meta leyar wrt mediatek workspace
#               TAG & Branch
######################################################################################

msg_WRONG_TARGET="Wrong target specified.  Please select 'conti', 'pana' or 'mediatek' as option\n"
msg_USAGE="$0    <base-path> <target> 
\n\t\t<base-path>    - arg1, base path for repo workspace
\n\t\t<target>       - arg2, target  'mediatek', 'conti', 'pana'"

[ $# -lt 1 ] && echo -e $msg_USAGE && exit 1

basepath=$1
target=$2
 
#[[ $target != "conti" ]] && [[ $target != "mediatek" ]] &&  echo -e $msg_WRONG_TARGET && exit 1

repo_workspce=$basepath/$target
#SCRIPT_DIR=$(dirname $(readlink -f "$0"))
build_branch="konfluence_conti_mediatek_iip"
#meta_layers=("meta/meta-konfluence meta/meta-kivi")
meta_konfluence=$repo_workspce/meta/meta-konfluence
meta_kivi=$repo_workspce/meta/meta-kivi

echo "checking for conti specific repos @ $meta_konfluence"
bbappend_files=$(find $meta_konfluence -name "*.bbappend" -exec grep -wl "$build_branch" {} \;)

printf "konfluence-adas-image.bbappend diff=nodiff \nkonfluence-cluster-image.bbappend diff=nodiff \nkonfluence-dom0-image.bbappend diff=nodiff \nktelltale.bbappend diff=nodiff \nkiviclient.bbappend diff=nodiff" > $meta_konfluence/.git/info/attributes  && echo "Added skiping *.bbappned files to $meta_konfluence/.git/info/attributes"

printf "kiviclient.bb diff=nodiff \nktelltale.bb diff=nodiff \nkrux.bb diff=nodiff \nkdriverassistclient.bb diff=nodiff \nkonfluence-adas-image.bb diff=nodiff" > $meta_kivi/.git/info/attributes  && echo "Added skiping *.bbappned files to $meta_kivi/.git/info/attributes"

for i in $bbappend_files; do 
   var=$(basename $i)        
   echo "$var diff=nodiff" >> $meta_konfluence/.git/info/attributes
   echo  "`echo $var | awk -F "." '{print $1}'`.bb  diff=nodiff" >> $meta_kivi/.git/info/attributes
done

#meta-konfluence
    cd $meta_konfluence
    [[ ! -f .git/info/attributes ]] &&  echo "No attribues file exits" && exit 1;
    git config diff.nodiff.command /bin/true
    git diff konfluence..konfluence_conti_mediatek_iip  *.bbappend  #| git apply -R

#meta-kivi
   cd $meta_kivi
   [[ ! -f .git/info/attributes ]] &&  echo "No attribues file exits" && exit 1;
   git config diff.nodiff.command /bin/true
   git diff konfluence..konfluence_conti_mediatek_iip  *.bb  #| git apply -R

exit 0;
