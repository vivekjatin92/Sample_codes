#!/bin/bash

#############################################################################

# Author: Amit Shinde.
# Desc:  Script will update TAG and BRANCH for componunt .bbappend file

#############################################################################

msg_WRONG_TARGET="Wrong target specified.  Please select 'conti', 'pana' or 'mediatek' as option\n"

basepath=$1
target=$2

[[ $target != "conti" ]] && [[ $target != "pana" ]] && [[ $target != "mediatek" ]] && echo -e $msg_WRONG_TARGET && exit 1

SCRIPT_DIR=$(dirname $(readlink -f "$0"))
repo_workspace="$basepath/$target"   #meta DIR path
csvFilePath=$SCRIPT_DIR/yocto_kap_ticket_data.csv       #input csv file path [yocto_data_parser.sh o/p file]
source $SCRIPT_DIR/yocto.config
source $SCRIPT_DIR/build_utils.sh
target_branch=$MP_branch
[[ "$target" = "conti" ]] && target_branch=$Conti_branch

empty_check=$(cat $csvFilePath | wc | awk '{print $2}')
if [ "$empty_check" == "0" ]; then echo "No new ticket :: build will not triggerd"; exit 0; fi
sed -i '1d' $csvFilePath && echo " Removed Header line form  $csvFilePath"

yocto_meta_layers_pull $repo_workspace $target_branch

cat $csvFilePath |
while read data
do
        cmpName=$(echo "$data" | cut -d "," -f4)
        tagName=$(echo "$data" | cut -d "," -f6)
        BranchName=$(echo "$data" | cut -d "," -f7)
        cd $repo_workspace/meta
        BaseName=$(basename $cmpName)              # cmp name form cpm path
        cmpName=$(echo $BaseName | cut -d "." -f1) # removed .git from cmp name 
        [[ "$cmpName" = *"konfluence"* ]] &&  cmpName=$(echo $cmpName | cut -d "_" -f2)  # if 'konfluence' is present in name
        bbappendFile=$(find . -name $cmpName*.bbappend)
        echo "########## $bbappendFile #########"
        if [  ! -z "$bbappendFile" ]
        then
            TAG=$(echo "TAG="'"'$tagName'"'"")
	    BrName=$(echo "BRANCH="'"'$BranchName'"'"")
	    sed -i -r "`grep -nw "TAG" $bbappendFile | awk -F":" '{print $1 }'`"s"#.*#$TAG#g" $bbappendFile && echo "DONE:$TAG"
	    sed -i -r "`grep -nw "BRANCH" $bbappendFile | awk -F":" '{print $1 }'`"s"#.*#$BrName#g" $bbappendFile && echo "DONE : $BrName"

        else
                echo ".bbappend File not found for component $cmpName"
        fi

done
git_push_opertion(){
   TaskID=$(cat $csvFilePath | awk -F"," 'BEGIN { OFS = " "} { printf $1 " " }')
   cd $repo_workspace/meta/meta-konfluence
   git_commit_msg="${target^^} : Integarted task $TaskID" && echo $git_commit_msg
   git add .
   git commit -m "$git_commit_msg"
   git push BMS $target_branch
}
git_push_opertion
yocto_build_tag $repo_workspace $target_branch
exit 0;
