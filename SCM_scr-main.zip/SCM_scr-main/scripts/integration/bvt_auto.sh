#!/bin/bash
#####################################################################
# Author : Amit Shinde
# Desc   : Script will perform BVT and genrate o/p file 

	# sudo apt-get install android-tools-fastboot     -fastboot 
	# sudo apt-get install android-tools-adb          -adb tools
	# adb logcat -G 5M && adb logcat > triel.txt      -logcat
######################################################################

msg_WRONG_TARGET="Wrong target specified.  Please select 'conti', 'pana' or 'mediatek' as option\n"
msg_USAGE="$0    <base-path> <target>
\n\t\t<target>       - arg2, target  'mediatek', 'conti', 'pana'
\n\t\t <build_no>    - Build no which you want to perform BVT"

[ $# -lt 2 ] && echo -e $msg_USAGE && exit 1

basepath=$(dirname $(readlink -f "$0"))
target=$1
build_no=$2
[[ $target != "conti" ]] && [[ $target != "pana" ]] && [[ $target != "mediatek" ]] && echo -e $msg_WRONG_TARGET && exit 1

build_apache_url="http://10.52.214.55/kivi_android/Sdk/$build_no/$build_no.tar.gz"   # for triel purpose

[[ ! -d $basepath ]] && echo "$basepath not found " && exit 1;
mkdir -p $basepath/tmp && cd $basepath/tmp


# Collecting build artifets 
collect_build_artifects(){
  wget -nv  $build_apache_url && tar -xzf *.tar.gz 
  [[ ! -f emmc_files/system.img ]] && echo "emmc_files is not correct " && exit 1;\
  rm -rf *.tar.gz && echo "Deleted target tar.gz file from $PWD"
  build_no=$(cat ./emmc_files/build_Info/artifects_signature.txt | head -n 1)
  echo "build_no= $build_no"
  cd $basepath && mv tmp/ $build_no
  bvt_status="$basepath/$build_no/$build_no.bvt" && touch $bvt_status
}

# adb device avialabilty test
check_connectivity_with_target_device(){
    ADB_PATH=$(which adb)
    ADB_OUT=`$ADB_PATH devices | awk 'NR>1 {print $1}'`       
    [[ -z "$ADB_OUT" ]] && echo "No device Found" && return 1;
    return 0;
}

# Enableing fastboot fir host machine to run auto flashing script
disable_hw_keys_for_flashing(){
     adb devices
     adb reboot-bootloader   && echo "adb reboot-bootloader done"
     fastboot devices
     cp -v $basepath/flashing.sh $basepath/$build_no/emmc_files  && echo "flashing copied"
}

HMI_apk_permissions_grant(){  # optimization is pending
    
         #loaction permissions
         adb shell pm grant com.kpit.androidauto android.permission.ACCESS_COARSE_LOCATION
         adb shell pm grant com.kpit.applecarplay android.permission.ACCESS_COARSE_LOCATION
	 adb shell pm grant com.kpit.settings android.permission.ACCESS_COARSE_LOCATION
         # contact access permission
         adb shell pm grant com.kpit.settings  android.permission.READ_CONTACTS
	 adb shell pm grant com.kpit.settings  android.permission.WRITE_CONTACTS
         adb shell pm grant com.kpit.phonebook  android.permission.READ_CONTACTS
	 adb shell pm grant com.kpit.phonebook  android.permission.WRITE_CONTACTS
         # phone call log acess permissions
         adb shell pm grant com.kpit.phonebook  android.permission.READ_CALL_LOG
	 adb shell pm grant com.kpit.phonebook  android.permission.WRITE_CALL_LOG
	 adb shell pm grant com.kpit.settings  android.permission.CALL_PHONE
         # External storage acess permissions
	 adb shell pm grant com.kpit.settings  android.permission.READ_EXTERNAL_STORAGE
 	 adb shell pm grant com.kpit.settings  android.permission.WRITE_EXTERNAL_STORAGE
         # set default app 
         adb shell settings put secure dialer_default_application com.kpit.phoneapp
         adb shell settings put secure android.app.role.DIALER  com.kpit.phoneapp
         #Alexa perissions
        adb shell pm grant com.kpit.alexaapp android.permission.RECORD_AUDIO
	adb shell pm grant com.kpit.alexaapp android.permission.ACCESS_FINE_LOCATION
	adb shell pm grant com.kpit.alexaapp android.permission.ACCESS_COARSE_LOCATION
	adb shell pm grant com.kpit.alexaapp android.permission.WRITE_EXTERNAL_STORAGE
	adb shell pm grant com.kpit.alexaapp android.permission.READ_CONTACTS
	adb shell pm grant com.kpit.alexaapp android.permission.WRITE_CONTACTS
	adb shell pm grant com.kpit.alexaapp android.permission.WRITE_CALL_LOG
	adb shell pm grant com.kpit.alexaapp android.permission.READ_CALL_LOG
	adb shell pm grant com.kpit.alexaapp android.permission.READ_EXTERNAL_STORAGE
}


# Check for HMI aps are launching or not
bvt_HMI_home_screen_apk(){
        adb root && adb remount
	home_screen_apk=("HVAC" "AndroidAuto" "AppleCarPlay" "Volumemanager" "Phonebook"  "Media" "Settings" "Alexa" "Navigation" "Phone" )
        HMI_apk_permissions_grant
        logcat_msg="topActivity=ComponentInfo{com.kpit"
        for apk in "${home_screen_apk[@]}"; do
            lowercase_apk=$(echo "${apk,,}")
            if [ "$lowercase_apk" == "phone" ];then lowercase_apk="phoneapp"; fi
            if [ "$lowercase_apk" == "alexa" ];then lowercase_apk="alexaapp"; fi
            if [ "$lowercase_apk" == "volumemanager" ];then apk="VolumeController"; fi
            adb shell am start -n com.kpit.$lowercase_apk/com.kpit.$lowercase_apk.view.${apk}ViewManager
            sleep 8;
            timeout 8 adb logcat | grep $logcat_msg.$lowercase_apk >> $basepath/$build_no/apk_logcat.log
            taskID=$(cat $basepath/$build_no/apk_logcat.log | grep  $logcat_msg.$lowercase_apk | awk '{print $13 "" $14}')
            if test -z "$taskID"; then echo -e "${apk} : FAIL">> $bvt_status; else echo -e "${apk} : PASS ">> $bvt_status; fi
            adb shell am start -n com.kpit.launcher/.activity.MainActivity
            sleep 5;
        done
        failuer_check=$(cat $bvt_status | grep -i FAIL | wc -l) 
        pass_check=$(cat $bvt_status | grep -i PASS | wc -l)
        echo -e " \n # HMI APK Total Count : ${#home_screen_apk[@]} \n # HMI APK PASS Count : $pass_check \n # HMI APK FAIL Count : $failuer_check" >> $bvt_status
        #rm -rf $basepath/$build_no/apk_logcat.log
}

# check for Basic konfluence services is running or not
bvt_basic_konfluence_services(){
        echo "Performimng Basic konfluence services BVT"
        fail_count=0
	basic_services=( "weston" "/dev/kbinder" "konfluence_audio_master" "konfluence_display_master" "konfluence_vehicle_gateway" "konfluence_power_manager" "konfluence_diagnostic_manager" "local_health_monitor_dom0" "central_health_manager" "kivi_service_manager" "ProjectionServiceCore" "kpit.tuner.service" "com.kpit.konnectapp" "clusterrenderer" "kvdacd")
        for service in "${basic_services[@]}"; do
	   PID=$(adb shell ps -ef | grep -m 1 $service | awk '{print $2}')
	   if test -z "$PID"; then echo -e "${service} : FAIL">> $bvt_status;$fail_count=$((fail_count+1)) ; else echo -e "${service} : PASS ">> $bvt_status; fi
       done
       total_count=$(echo ${#basic_services[@]})
       pass_count=`expr $total_count - $fail_count`
       echo -e " \n # Requried Services Total Count : $total_count \n # Requried Services PASS Count : $pass_count \n # Requried Services FAIL Count : $fail_count" >> $bvt_status
}

echo "Collecting build artifets wrt build: $build_apache_url"
collect_build_artifects

# function call for device avaiblity chcek
check_connectivity_with_target_device ;[[ $? == "1" ]] && echo "NO adb device Found" && exit 1;

disable_hw_keys_for_flashing  && echo "enabled flashing"

# emmc_files Flashing on target
cd $basepath/$build_no/emmc_files && pwd
sudo ./flashing.sh
echo "waiting for 1 min. to complete boot up" && sleep 80;

# check for Boradt boot up upadte
echo -e "BVT Time: `date +"%r"` On Date: `date +"%m-%d-%Y"`" >>$bvt_status
board_boot_status=$(adb shell getprop sys.boot_completed | tr -d '\r')
if [ "$board_boot_status" != "1" ]; then echo -e "\nBoot-up : FAIL" >>$bvt_status; exit 1; else echo -e "Boot-up : PASS " >>$bvt_status; fi

echo -e "\n------ BVT_Status_For_HMI_Launcher_Screen _Apk-----------\n" >>$bvt_status   
bvt_HMI_home_screen_apk

echo -e "\n------ BVT_Status_For_Basic_Konfluence_Services-----------\n" >>$bvt_status
bvt_basic_konfluence_services

exit 0;

