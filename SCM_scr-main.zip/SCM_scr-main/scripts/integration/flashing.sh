#!/bin/bash

echo "---------------------------------------"
echo "        Target Flashing Script       "
echo "---------------------------------------"
#echo " 1 > Press and hold SW2 <Download> key "
#echo " 2 > Press SW5 <Power> Key once        "
#echo " 3 > Hit Enter                         "
#read -n 1 -s -r
#echo " Flasing started... Hold SW2 <Download> key "
sleep 1 

# This step is mandatory. It flashes an empty bl2 first so that there is no 
# residue left from a previous image. Please do not remove this

#sudo ./fastboot flash EMPTY bl2.img
#sleep 1
#sudo ./fastboot continue
#sleep 1

sudo ./fastboot erase mmc0
sleep 1
sudo ./fastboot erase mmc0boot0
sleep 1
sudo ./fastboot erase mmc0boot1
sleep 2
sudo ./fastboot flash mmc0 MBR_EMMC

sudo ./fastboot flash mmc0boot0 MBR_EMMC_BOOT0
sudo ./fastboot flash mmc0boot1 MBR_EMMC_BOOT1

#echo "====== YOU CAN RELEASE DOWNLOAD KEY NOW. ======"
#echo " Release SW2 <Download> Key and Hit Enter      "
#read -n 1 -s -r

sudo ./fastboot erase system_a
sudo ./fastboot erase userdata
sudo ./fastboot erase vendor_a
sudo ./fastboot erase vbmeta_a
sudo ./fastboot erase adas_a

sudo ./fastboot flash bl2_a bl2.img
sudo ./fastboot flash bl2_b bl2.img

sudo ./fastboot flash tee_a tee.img
sudo ./fastboot flash tee_b tee.img

sudo ./fastboot flash scpsys_a scp.img
sudo ./fastboot flash scpsys_b scp.img

sudo ./fastboot flash scpdata scp-data.img

sudo ./fastboot flash bl33_a bl33.img
sudo ./fastboot flash bl33_b bl33.img

sudo ./fastboot flash vpd vpd.img

# Presently we are flashing only bank A
sudo ./fastboot flash boot_a boot.img

# Following image files are coming from yocto build. The names here are actually
# soft links to the actual file with extension .ext4

sudo ./fastboot flash dom0_a konfluence-dom0.img
sudo ./fastboot flash adas_a konfluence-adas.img
sudo ./fastboot flash cluster_a konfluence-cluster.img
sudo ./fastboot flash persist_a persist.img
sudo ./fastboot flash persist_b persistbk.img

sudo ./fastboot flash system_a system.img 
sudo ./fastboot flash userdata userdata.img 
sudo ./fastboot flash vendor_a vendor.img
sudo ./fastboot flash vbmeta_a vbmeta.img --disable-verity

sudo ./fastboot flashing unlock

sudo ./fastboot reboot
adb wait-for-device
A=$(adb shell getprop sys.boot_completed | tr -d '\r')
while [ "$A" != "1" ]; do
sleep 2
A=$(adb shell getprop sys.boot_completed | tr -d '\r')
done
adb shell wm size 1920x720

echo $PWD
cd 
echo $PWD
TTFileName="TomTom_dependency.tar"
TTFolderName="TomTom_dependency"

InsertTomTomfile()
{    		
	cd TomTom_dependency
	echo $PWD
	printf "Pushing TomTom Dependancy on target.Please Wait !!!\n"
	adb wait-for-device
	A=$(adb shell getprop sys.boot_completed | tr -d '\r')
	while [ "$A" != "1" ]; do
        	sleep 2
        A=$(adb shell getprop sys.boot_completed | tr -d '\r')
	done
	./install_tomtom_resource.sh && echo "TT Navigation data pushed on target.. Sucessfull!!!"
	echo "Granting permissions to Navigation....."
	adb shell am start -n com.kpit.navigation/com.kpit.navigation.view.NavigationViewManager
	sleep 4
	adb shell pm grant com.kpit.navigation android.permission.ACCESS_FINE_LOCATION
	adb shell pm grant com.kpit.navigation android.permission.READ_EXTERNAL_STORAGE
	adb shell pm grant com.kpit.navigation android.permission.ACCESS_COARSE_LOCATION
	adb shell pm grant com.kpit.navigation android.permission.READ_PHONE_STATE
	adb shell pm grant com.kpit.navigation android.permission.WRITE_EXTERNAL_STORAGE
	sleep 3
	printf "Rebooting target. \nPlease Wait !!!\n"
	sleep 3 
	adb reboot
	printf "Please do HardKey Power ON/OFF cycle once!!!\n"
}

if [ -d $TTFolderName ]
then
	printf "TomTom file is present \n" 
	InsertTomTomfile

elif [ -f $TTFileName ] && [ ! -d $TTFolderName ]
then
		printf "Compressed TomTom Dependancy file !!!\n"
		printf "Extracting TomTom Dependancy.Please Wait !!!\n"
		sleep 2
		tar -xvf  $TTFileName && echo "TT Data Extaction complete ! \n"
		sleep 2
		InsertTomTomfile

else
	printf "TomTom_dependancy File is not preset \n "
	adb reboot
	printf "Please do HardKey Power ON/OFF cycle once!!!\n"
fi


