#!/bin/bash

build_no=$1
BVT_file_path="/zen/kivi_android/Sdk/$build_no/$build_no.bvt"
Push_file_path="/zen/kivi_android/bvt_status"  # gerrit repo

cd $Push_file_path && pwd
if [ ! -f "$BVT_file_path" ]; then echo "$build_no:Pending" > $BVT_file_path ; fi
bvt_status=$(cat $BVT_file_path | head -n 1 | awk -F":" '{print $2}')
week=$(echo "`date +"%y"`CW`date +"%U"`")
check_week=$(grep -w "$week" $Push_file_path/bvt_status.md)
if [ -z $check_week ]; then sed -i '5i'"$(echo '| | **Week No : '$week'** | |')" $Push_file_path/bvt_status.md; fi
sed -i '6i'"$(echo '|'$build_no' |'$bvt_status' | ['$build_no'.bvt]('$apache_url')|')" $Push_file_path/bvt_status.md
git commit -am "Upadted bvt_status.md file wrt Build[$build_no] details"
git push origin konfluence_dev

# For Gitlab stage status
if [ "$bvt_status" == "PASS" ]; then echo "BVT PASS";exit 0; else echo "BVT fail" && exit 1; fi
