#!bin/bash

USER_ID=${LOCAL_UID:-9001}
GROUP_ID=${LOCAL_GID:-9001}

echo "Starting with {UID:$USER_ID, GID:$GROUP_ID}"
useradd -u $USER_ID -o -m kpit
groupmod -g $GROUP_ID kpit

mkdir -p /home/kpit/.ssh

cp /usr/local/src/id_rsa /home/kpit/.ssh/id_rsa
cp /usr/local/src/known_hosts /home/kpit/.ssh/known_hosts

chown kpit /home/kpit/.ssh/id_rsa
chown kpit /home/kpit/.ssh/known_hosts

export HOME=/home/kpit 
exec gosu kpit bash -c 'cd /konfluence && source meta/poky/oe-init-build-env build/ && source vivek.bat'

