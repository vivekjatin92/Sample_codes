#!/bin/bash
################################################################################
	#Author : Amit Shinde
	# Desc:   script will perfrom docker installtion and docker image creation for specified type
################################################################################

msg_WRONG_TARGET="Wrong target [2 argv] specified.  Please select 'aosp', or 'yocto' as option\n"
HMI_MSG="Do you need HMI build\n If you enter 'no' then dummy HMI apk will be placed in build\n If you enter 'yes' then only actual HMI build will perform and working .apk will be placed in build: \n"

basepath=$1
build_type=$2        # aosp/yocto

echo "Installing Docker"
curl -fsSL https://get.docker.com -o get-docker.sh  && echo "get-docker.sh collected" && chmod a+x get-docker.sh
sudo ./get-docker.sh
[[ $? -eq 1 ]] && echo "Docker installtion failed" && exit 1;

echo "Setting Docker as not root user"
printf "`id`"
GID=$(id -g $USER)
sudo groupadd -g $GID docker    # 996 might be need to change
sudo usermod -aG docker $USER
sync && printf "`id`" 

[[ ! -d $basepath ]] && echo "Basepath incorrect or directory doesn't exits :- $basepath" && exit 1     # eg. /kpit
[[ $build_type != "aosp" ]] && [[ $build_type != "yocto" ]] &&  echo -e "$msg_WRONG_TARGET" && exit 1

mkdir -p $basepath/$build_type && cd $basepath/$build_type     # eg. /kpit/aosp || /kpit/yoct

echo "featching Scripts repo inside $basepath/$build_type"
[[ ! -d scripts ]] && git clone http://hjph3androidivi.kpit.com:8080/scripts 
cd $basepath/$build_type/scripts  && pwd
git checkout master && git pull

echo "Copiny $build_type.config to $basepath/$build_type"
cd  docker/config.$build_type/ 
cp -v  * .bashrc .gitconfig .netrc $basepath/$build_type

echo "Upadating uid and gid for docker username wrt current user : $USER"
cd $basepath/$build_type/scripts/docker  && pwd
echo "$USER - uid :- $UID & gid = $GID"
template1="RUN groupadd --gid $GID kpit "
template2="RUN useradd --uid $UID --gid kpit --create-home kpit"
sed -i -r "`grep -nw "groupadd --gid" Dockerfile_$build_type | awk -F":" '{print $1 }'`"s"#.*#$template1#g" Dockerfile_$build_type  && echo "modified userID"
sed -i -r "`grep -nw "useradd --uid" Dockerfile_$build_type | awk -F":" '{print $1 }'`"s"#.*#$template2#g" Dockerfile_$build_type && echo "modified groupID"

echo "Building Docker image for $build_type"
sudo docker build -f Dockerfile_$build_type --rm --memory-swap=-1 -t ubuntu_$build_type:v1 .

cd $basepath/$build_type
[[ $build_type == "aosp" ]] && read -r -t 120 -p "`printf "$HMI_MSG "`"  user_var
[[  -z "$user_var" ]] && echo "You have not entered value, so script will take default value as 'no'" && user_var="no"

if [ \( "$build_type" == "aosp" -a "$user_var" == "yes" \) ]; then
   echo "Featchinh Android SDk "
   [[ ! -d Android ]] && wget -nv http://10.52.214.55/kivi_android/Tools/Android_sdk.tar.gz && tar -xvzf Android_sdk.tar.gz && rm -rf Android_sdk.tar.gz
elif [ \( "$build_type" == "aosp" -a "$user_var" == "no" \) ]; then
   printf "Skiping HMI Build\n Added Dummy HMI Apk"
   mkdir -p $basepath/$build_type/mediatek && cd $basepath/$build_type/mediatek
   [[ ! -d /.repo ]] &&  wget -nv http://10.52.214.120/ga_conti_repo/conti_repo.tar.gz && tar -xvf conti_repo.tar.gz && rm -rf conti_repo.tar.gz
   repo init -u http://hjph3androidivi.kpit.com:8080/platform/omapmanifest -b aosp_mtk_hmi_ga_release -m hmi_mtk_manifest_ga_release.xml --no-repo-verify
   repo sync -j`nproc` && cd ../
   [[ ! -f /APK.tar.gz ]] && wget http://10.52.214.55/kivi_android/Tools/APK.tar.gz && tar -xzf APK.tar.gz
   cp -rv APK/* $basepath/$build_type/mediatek  ## testing needed
 fi
 read -r -t 120 -p "Need system reboot please enter yes/no"  rebbot_var
 [[ $build_type == "yes" ]] && sudo reboot;
 
exit 0;

