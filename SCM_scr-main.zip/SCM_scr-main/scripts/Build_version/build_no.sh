#!/bin/bash

###################################################
# Author  :: Amit Shinde
# Desc    :: manageengine the build No. [aosp/yocto]
###################################################

    target=$1
    type=$2
    operation=$3
    build_no_file=$(echo "build_no_$type.txt")   #specific path for AOSP Or Yocto
    next_week=$(date +"%U")
#    next_week="$((curr_week+1))"
    curr_year=$(date +"%y")
    week_no=$(sed -r 's/.* week:([0-9]+), .*/\1/g' $build_no_file)
    target_cap=${target^}

read_build_no(){
    version=$(sed -r 's/.* '"$target"':([0-9]+)(.*)/echo \1/ge' $build_no_file)
    BuildNo=$(printf "%02dCW%02dDB%02d%s\n" $curr_year $((10#$next_week))  $version ${target_cap:0:1})
    echo $BuildNo
}

update_build_no(){
    [[ $next_week != $week_no ]] && echo "build:0, week:$next_week, mediatek:0, conti:0, pana:0" > $build_no_file
    sed -r -i 's/build:([0-9]+), (.*)('"$target"':)([0-9]+)(.*)/echo "build:$((\1+1)), \2\3$((\4+1))\5"/ge' $build_no_file
    version=$(sed -r 's/.* '"$target"':([0-9]+)(.*)/echo \1/ge' $build_no_file)
    BuildNo=$(printf "%02dCW%02dDB%02d%s\n" $curr_year $((10#$next_week))  $version ${target_cap:0:1})
    echo $BuildNo
}

reverse_build_no(){
     sed -r -i 's/build:([0-9]+), (.*)('"$target"':)([0-9]+)(.*)/echo "build:$((\1-1)), \2\3$((\4-1))\5"/ge' $build_no_file
}
increment_build_no(){
    version=$(sed -r 's/.* '"$target"':([0-9]+)(.*)/echo \1/ge' $build_no_file)
    version=$((version+1))
    BuildNo=$(printf "%02dCW%02dDB%02d%s\n" $curr_year $((10#$next_week))  $version ${target_cap:0:1})
    echo $BuildNo
}
decrement_build_no(){
    version=$(sed -r 's/.* '"$target"':([0-9]+)(.*)/echo \1/ge' $build_no_file)
    version=$((version-1))
    BuildNo=$(printf "%02dCW%02dDB%02d%s\n" $curr_year $((10#$next_week))  $version ${target_cap:0:1})
    echo $BuildNo
}


[[ $operation == "read" ]]  &&  read_build_no
[[ $operation == "update" ]]  &&  update_build_no
[[ $operation == "reverse" ]]  && reverse_build_no
[[ $operation == "increment" ]]  && increment_build_no
[[ $operation == "decrement" ]] && decrement_build_no
