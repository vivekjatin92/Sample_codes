#!/bin/bash
#
# pending incremental/force build/update

echo "Kidoor" >> /kpit/avinash.txt

cd /kpit/aosp/sca

repo init -u http://hjph3androidivi.kpit.com:8080/platform/omapmanifest -b konfluence_dev -m konfluence_conti_mediatek_iip.xml --no-repo-verify >> /kpit/avinash.txt
repo sync -j 8 >> /kpit/avinash.txt

echo "Bhandary - $PWD" >> /kpit/avinash.txt

