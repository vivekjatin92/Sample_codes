#!/bin/bash

# Amit Shinde: - scripts to collect screen session logs
#logfile "$HOME/tmp/screen_LOG/screenlog.%S"  , will create screen log file  with screen name ($HOME .screenrc)

log_path="$HOME/tmp/screen_LOG"
log_zip_path="$log_path/zip_files"
mkdir -p $log_path/tmp && mkdir -p $log_zip_path && cd $log_path
for file in `ls screenlog*`;  do
    echo $file
    if [ -f "$log_zip_path/$file.zip" ]; then
       cd $log_path/tmp
       tar -xzf $log_zip_path/$file.zip  #untar it
       echo "### Time: `date +"%r"` On Date: `date +"%m-%d-%Y"` ###" >> $file # add date stamp
       cat $log_path/$file >> $file # append toadys log history
       tar -czf $log_zip_path/$file.zip $file  # again tar it with same name
       rm -rf $log_path/$file   # delete log file
    else
       cd $log_path
       tar -czf $log_zip_path/$file.zip  $file 
       rm -rf $log_path/$file #create zip and delete log file
    fi
done
rm -rf $log_path/tmp
exit 0;
