#!/bin/bash
###########################################
# Description: Generate ssh key and upload to remote machine for auto
#               authentication and add alias in .bashrc file.
# Author: Suryakant
# Amit Shinde : V2. modification wrt scalble(HOSTs) and .bashrc copy 
###########################################

HOSTS="bms@10.52.214.120 bms@10.52.214.78 vivekk@10.52.214.55 kivi@10.52.11.24 bms@10.52.214.65"
local_IP=$(hostname -I | awk -F ' ' '{print $1}')
SCRIPT_DIR=$(dirname $(readlink -f "$0"))

FILE=~/.ssh/id_rsa.pub
if [ -f "$FILE" ]; then
    echo "ssh key is already exist."
else
    echo "ssh key is not generated."
    echo | ssh-keygen -t rsa
fi

for HOSTNAME in ${HOSTS} ; do
    echo $HOSTNAME
    host_IP=$(echo $HOSTNAME | awk -F '@' '{ print $2 }')
    [[ $host_IP == $local_IP ]] &&  echo "HOST machine skiping" && continue;

    host_user=$(echo $HOSTNAME | awk -F '@' '{ print $1 }')
    cat ~/.ssh/id_rsa.pub | ssh $HOSTNAME "cat >> ~/.ssh/authorized_keys && uniq ~/.ssh/authorized_keys | tee ~/.ssh/authorized_keys >> /dev/null && chmod 600 ~/.ssh/authorized_keys"
    scp -r $SCRIPT_DIR/.bashrc $HOSTNAME:/home/$host_user  && echo ".bashrc copied to $HOSTNAME:/home/$host_user path )"

    echo "-                                         -"
    server=$(echo $host_IP |  awk -F '.' '{ print $4 }')
    [[ ! -z $server ]] && echo "Alisa to $HOSTNAME is $server" && echo alias $server="'ssh $HOSTNAME'" >> ~/.bashrc
    echo "-----------------------------------------"
done
