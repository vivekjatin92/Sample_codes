#!/bin/bash
# TODO: update all servers with following commands

cd /kpit/aosp/scripts
git pull
cd /kpit/yocto/scripts
git pull

