[ `docker ps | wc -l` -gt 1 ] && echo "==============" `date` &&  sudo docker stats --no-stream

