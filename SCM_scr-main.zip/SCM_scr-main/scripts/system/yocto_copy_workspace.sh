#!/bin/bash
msg_USAGE="$0    <target>
\n\t\t<target>       - arg1, target  'mediatek', 'conti', pana is same as mediatek"
target=$1

[[ $target != "conti" ]] && [[ $target != "mediatek" ]] && echo -e $msg_WRONG_TARGET && exit 1
ssh bms@10.52.214.78: "cd ~ && tar -jcvf ../package.xz --exclude='./build/cache' --exclude='./build/tmp' /kpit/yocto/$target"
scp bms@10.52.214.78:~/$target.xz .
tar xvf $target.xz
