#!/bin/bash
##############################################################################
# Author  : Amit Shinde
# Desc    : Script will monitor any DIR for event like modify,create,delete,move
#           and genrate on event ..
##############################################################################

today=$( date +%B%d)
echo $today
my_function(){
#build triggerd
echo "file changes"
cd $HOME/yocto_scripts/
./set_up.sh
cd -
}

while true; do
echo "-------Iteration Start------------"
inotifywait -e modify,create,delete,move -r $HOME/yocto_tickets/ && my_function
declare -i start=1
done
