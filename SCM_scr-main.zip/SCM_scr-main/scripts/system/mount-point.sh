msg_WRONG_TARGET="Wrong build type specified for mount"
msg_USAGE="Use mount_point.sh <build type>    i.e.,  'yocto' or 'aosp'\n\n"

[ $# -lt 1 ] && echo -e $msg_USAGE && mount | grep kpit && exit 1

build_type=$1

[[ $build_type != "yocto" ]] && [[ $build_type != "aosp" ]] && echo -e $msg_WRONG_TARGET && exit 1

kpit_base=/kpit/$1

declare -a mount_dir_yocto=(".repo" "downloads")
declare -a mount_dir_aosp=(".repo" "prebuilts")

mount_points=$(mount)
[[ $build_type == "yocto" ]] && mount_dir=$mount_dir_yocto
[[ $build_type == "aosp" ]] && mount_dir=$mount_dir_aosp

[[ $mount_dir == "" ]] && echo "${mount_points[@]}, mount_dir is empty : $mount_dir" && exit 1

exit 0

for dir in "${mount_dir[@]}"
{
  dir_fullpath=$(readlink -f $dir)
  echo "Processing ...  $dir"

  # check whether current directory has mount point entry
  # test case = true; dir_fullpath="/run/docker/netns/51f0ceaa3a50"
  if [[ ! " ${mount_points[@]} " =~ " ${dir_fullpath} " ]]; then
    echo "No mount point for $dir_fullpath"
    if [ ! -d  $dir ]; then
      mkdir $dir && sudo mount --bind $kpit_base/$dir $dir 
      [ $? -eq 0 ] && echo "Mount point created for $dir_fullpath at $kpit_base/$dir"
      [ $? -ne 0 ] && echo "Error mounting $dir_fullpath at $kpit_base/$dir"
    fi
  fi
}

