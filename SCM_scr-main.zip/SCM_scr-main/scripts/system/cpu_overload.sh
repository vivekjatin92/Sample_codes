#!/bin/bash

pmd_usage=$(ps u -C pmd | awk '!/^USER/' | cut -d " " -f7)
mem_usage=$(free | awk '/^Mem/ { print $4*100/$2}')

echo $pmd_usage
echo $mem_usage
echo $cpu_usage
