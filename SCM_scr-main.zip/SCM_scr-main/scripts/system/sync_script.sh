#!/bin/bash

#---------------------------------Build servers----------------------------------------------------------
USERNAME=bms
HOSTS="10.52.214.120 10.52.214.78"

SCRIPT="cd /kpit/yocto/scripts;pwd; git pull; cd /kpit/yocto/scripts;pwd; git pull; cd ~/scripts;pwd; git pull"


for HOSTNAME in ${HOSTS} ; do
    echo $HOSTNAME
    ssh -l ${USERNAME} ${HOSTNAME} "${SCRIPT}"
    echo "--------------------------------"
done
echo "server 10.52.214.55"
ssh vivekk@10.52.214.55 "$SCRIPT"    # 55 server username is vivekk (not like all other vm .i.e bms)
#----------------------------------------------------------------------------------------------------------------
# Note: script need passwordless connection to all  bms servers, to enable passwordless please execute following command on tty:
        # ssh-copy-id bms@10.52.214.120
        # ssh-copy-id bms@10.52.214.78
        # ssh-copy-id vivekk@10.52.214.55

