echo "============== " `date`
du -h --max-depth=1 /home/bms /kpit | grep G


