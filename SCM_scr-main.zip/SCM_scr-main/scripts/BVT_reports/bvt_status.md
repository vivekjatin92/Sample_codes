

| Build No  | BVT-Status |    Target       |      Date      | Release Link  | Response Link| Sanity Report|
| ------------- | -------|---------------- |----------------|---------------|--------------|--------------|            
| | **Week No : 22CW14** | | | | |
|22CW14DB01C |PASS |Conti |April_07|[Released stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB01C.rel.html)| [Response stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB01C.res.html) |[sanity stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB01C.sanity.xls)
|22CW14DB02M |PASS |Mediatek|April_07 |[Released stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB02M.rel.html)| [Response stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB02M.res.html) | [sanity stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB02M.sanity.xls)|
|22CW14DB01M |PASS |Mediatek |April_06|[Released stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB01M.rel.html)| [Response stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB01M.res.html) |[sanity stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW14DB01M.sanity.xls)
|22CW13DB04C |PASS |Conti|April_05 |[Released stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW13DB04C.rel.html)| [Response stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW13DB04C.res.html) | [sanity stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW13DB04C.sanity.xls)|
| | **Week No : 22CW13** | | | | |
|22CW13DB05M |PASS | Mediatek |4/1/2022 | [Released stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW13DB05M.rel.html)| [Response stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW13DB05M.res.html) | [sanity stat](http://10.52.214.55/kivi_android/bvt_status/reports/22CW13DB05M.sanity.xls)|
