#!/bin/bash

###########################################################
# Author : Amit Shinde
# Desc: Script will upadte build status wrt BVT result and sanity report

#########################################################


build_no=$1
bvt_state=$2    # rel/pass/failed
bvt_tar=$3
bvt_date=`date +%B_%d`


SCRIPT_DIR=$(dirname $(readlink -f "$0"))
apache_path="http://10.52.214.55/kivi_android/bvt_status/reports"

bvt_rel_file="$apache_path/$build_no.rel.html"
bvt_res_file="$apache_path/$build_no.res.html"
sanity_report_file="$apache_path/$build_no.sanity.xls"

check_file(){
   [[ -f $1 ]] && echo 1; }


if grep -o $build_no  $SCRIPT_DIR/bvt_status.md; then 
     echo "$build_no entry already present"
     if grep -o "Pending" $SCRIPT_DIR/bvt_status.md; then
        echo " $build_no  BVT status updated from 'Pending' --> $bvt_state on  DashBoard"; 
        sed -i -r "`grep -nw "$build_no" $SCRIPT_DIR/bvt_status.md | awk -F":" '{print $1 }'`"s"#.*#$(echo '|'$build_no' |'$bvt_state' |'$bvt_tar'|'$bvt_date' |[Released stat]('$bvt_rel_file')| [Response stat]('$bvt_res_file') | [sanity stat]('$sanity_report_file')|')#g" $SCRIPT_DIR/bvt_status.md 

     else 
       echo "Provided $build_no details are already present on BVT DashBoard"; exit 1;
     fi
 else
     [[ "$bvt_state" == "release" ]] &&  bvt_state="Pending"

     week=$(echo "`date +"%y"`CW`date +"%U"`")  # ToDo .. covert into Decimal
     check_week=$(grep -w "$week" $SCRIPT_DIR/bvt_status.md)
     [[ -z $check_week ]] &&  sed -i '5i'"$(echo '| | **Week No : '$week'** | | |')" $SCRIPT_DIR/bvt_status.md

     sed -i '6i'"$(echo '|'$build_no' |'$bvt_state' |'$bvt_tar' |'$bvt_date'|[Released stat]('$bvt_rel_file')| [Response stat]('$bvt_res_file') |[sanity stat]('$sanity_report_file')')" $SCRIPT_DIR/bvt_status.md
fi
#git commit -am "Upadted bvt_status.md file wrt Build[$build_no] details"
#git push origin konfluence_ci

# For Gitlab stage status
#if [ "$bvt_status" == "PASS" ]; then echo "BVT PASS";exit 0; else echo "BVT fail" && exit 1; fi


