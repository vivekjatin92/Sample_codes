#!/bin/bash

##################################################################
# Author : Amit Shinde
# Desc   : Script will create gerrit account and send email 
# script calling pattern : sudo ./gerrit_acc_create.sh "Amit Shinde"
######################################################################

if [[ $(id -u) -ne 0 ]] ; then echo "Please run as root[sudo]" ; exit 1 ; fi
[ $# -lt 1 ] && echo -e "Provide developer name " && exit 1

dev_name=$1
uName=$(echo $dev_name | awk '{print tolower($1)toupper(substr($2,0,1))}')
emailID=$(echo $dev_name | nawk '{for(i=1;i<=NF;i++)sub(/./,toupper(substr($i,1,1)),$i)}1' | tr " " "." | awk '{print $1"@kpit.com"}')
AOSP_server="vivekk@10.52.214.55"

# prepare Username
prepare_UserName(){
   name=$1
   if [[ $name =~ [0-9] ]];then
        latest=$( echo $name | tr -dc '0-9')
        uName=$(echo "${uName}$((latest+1))")
   else
        uName=$(echo "${name}1")
   fi
}

#check uName
check_Uname=$(ssh -p 29418 admin@hjph3androidivi.kpit.com gerrit ls-members Administrators | awk '{print $2}' | grep  "$uName" |sort -n | tail -n 1)
[ ! -z "$check_Uname" ] && prepare_UserName $check_Uname

#Creating gerrit account
echo "$dev_name :: $uName :: $emailID"
sudo htpasswd -b /etc/apache2/gerrit.passwd $uName kpit123
[[ $? -eq 1 ]] && echo "Failed to create gerrit account for $uName" && exit 1;
echo "gerrit account sucessfully created Uname: $uName || Pass: kpit123"

# sending mail
message="Hi $dev_name,
Gerrit Account has been created for you :
UserNmae        : $uName
Password        : kpit123
Gerrit login URL: http://hjph3androidivi.kpit.com/

Please refer attached KAP link, and follow the steps to start gerrit account.
Link : https://kap.kpit.com/redmine/projects/kontinous-integration-and-delivery/wiki/Gerrit_Account_Setup#section-2
Reply back on E-mail ones you done with all steps.

Regards,
CM Team"

mail_send=$(ssh $AOSP_server "cd /kpit/aosp/scripts;python send_email.py $emailID \"$message\";")
echo $mail_send
