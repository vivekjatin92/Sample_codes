#!/bin/bash

#########################################################
# Author : Amit Shinde
# Desc   : Script will add gerrit server remote and push src on gerrit
############################################################

repo_workspace=$1
rmtO="git remote add origin ssh://admin@hjph3androidivi.kpit.com:29418"
delimiter=".com"
file="$HOME/tmp/remote.txt"

cd $repo_workspace
cat google_path.txt |
while read data
do
	echo $data "repo name@"
	if [ ! -d $data ]; then  echo "NOT-EXIT $data";continue; fi
	cd $data && pwd
	git remote -v > $file
	line=$(head -n 1 $file)
	string=$line$delimiter
	myarray=()
	while [[ $string ]]; do
	  myarray+=( "${string%%"$delimiter"*}" )
	  string=${string#*"$delimiter"}
	done
	LastNUM=$(echo "${myarray[1]}" | cut -d " " -f1)
	addOrigin=$(echo "$rmtO""$LastNUM")
	echo $addOrigin
	$addOrigin || echo $addOrigin
	git checkout -b android_dev
	git push origin android_dev
	cd -
done
