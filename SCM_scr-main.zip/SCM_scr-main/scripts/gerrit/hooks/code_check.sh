#/bin/bash

#static code analysis (SCA) tools variable.
sca_cpp=cppcheck
sca_java=pmd

if type $sca_cpp &> /dev/null; then 
  echo "$(tput setaf 2)$(cppcheck --version) is installed.$(tput sgr0)"

else
  #echo "$(tput setaf 1)cppcheck is missing, installing cppcheck ...$(tput setaf 0)"
  sudo apt-get install cppcheck
fi

if type $sca_java &> /dev/null; then
  echo "$(pmd --version)"
else
  cd $HOME
  if [ ! -d pmd-bin-6.37.0 ]; then
    if  [ ! -f pmd-bin-6.37.0.zip ];then
        wget https://github.com/pmd/pmd/releases/download/pmd_releases%2F6.37.0/pmd-bin-6.37.0.zip
    fi	    
    unzip pmd-bin-6.37.0.zip && rm pmd-bin-6.37.0.zip	
  fi 
  #Alias inside shell won't work normal way.
  #https://www.thegeekdiary.com/how-to-make-alias-command-work-in-bash-script-or-bashrc-file/
  shopt -s expand_aliases
  alias pmd="$HOME/pmd-bin-6.37.0/bin/run.sh pmd"
  echo "$(tput setaf 2)pmd setup is ready...!$(tput sgr0))"
fi

#Run SCA tools.
#cppcheck 
#pmd -d ./native -R rulesets/java/quickstart.xml -f text

commit_id=${12}

#git diff-tree --no-commit-id --name-only -r ${12}
git show $commit_id
git remote show $commit_id

