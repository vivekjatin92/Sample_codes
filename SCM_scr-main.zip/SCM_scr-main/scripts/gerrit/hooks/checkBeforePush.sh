#!/bin/bash
commit_id=${12}
commit_msg=$(git show -s --format=%B $commit_id)
#git diff-tree --no-commit-id --name-only -r ${12}
#domain_name=("HMI" "SYSTEM" "BSP")
#
commit_match=$(echo $commit_msg | grep -e '^[0-9]*:.*:.*:.*:.*:.*$')

#source hooks config.
source /tmp/hooks/hooks.config

# Commit message validation
if [[ ! -z $commit_match ]]
then	
	echo "$(tput setaf 2)commit message format is valid, code push is successfuly done..!$(tput sgr0)"
	#exit 0
else
	echo "$(tput setaf 1)commit message format is not valid, enter correctly formatted commit message, git push is failed!!!"
	echo "e.g. user_story_id:component_name:Domain Name:commit_msg:Dependency (Yes/No):build variants(MCP):Commit msg"
	echo "For Ex: 123456:HVAC:HMI:Yes/No:MCP:Integrate HVAC in AOSP 10$(tput sgr0)"
	#[[ $check_commit_mgs == "false" ]] && exit 0 # Allow push for invalid case.
	# exit 1
fi

### KAP ticket creation 
if [ "$create_ticket" == true ]
then
	title="$(echo $commit_msg | cut -d':' -f6)"
	#sed -i 's/subject_text/'"$title"'/g' /tmp/hooks/ticket_details.json
	#####################################################################
   	touch /tmp/hooks/t.json
   echo '{
           "issue": {
                   "project_id": 1,
                   "tracker_id": 1,
                   "status_id": 3,
                   "priority_id": 2,
                   "author_id": 1,
                   "assigned_to_id": 1,
                   "subject": "'"${title}"'",
                  "description": "konfluence/konfluence_audio_master.git"
          },
         "key": "d22d9666ebbcbeee5a40e2d6d911b9832259667c"
	}' >> /tmp/hooks/t.json
	#####################################################################	
	curl -v -H "Content-Type: application/json" -X POST --data-binary "@/tmp/hooks/t.json" \
          -H "X-Redmine-API-Key: d22d9666ebbcbeee5a40e2d6d911b9832259667c" http://10.52.214.120:3000/issues.json &>/dev/null
	#rm t.json
else
 	echo "KPA ticket creation is diabled, please enable to automate ticket creation."
fi

exit 0
