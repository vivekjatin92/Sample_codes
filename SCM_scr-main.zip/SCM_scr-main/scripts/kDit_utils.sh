#!/bin/bash

#  Author	     :- Amit Shinde
#  Set-Up prerequisite for
#  1  .netrc	     :- reg mediatek server authentication
#  2  .gitconfig     :- reg SSl certification settings


source $HOME/.bashrc

# Ntework proxy  set up in .gitconfig file
setUp_gitconfig(){

    checkHTTP=$(cat $HOME/.gitconfig | grep -i postBuffer)
    if [ test -z "$checkHTTP" ];
    then
        echo "[http]
            sslVerify = false
            postBuffer = 1048576000" >> $HOME/.gitconfig

	    echo "[https]
            sslVerify = false
            postBuffer = 524288000" >> $HOME/.gitconfig

	    echo "$(tput setaf 1)$(tput setab 7).gitconfig Updated with all Settings $(tput sgr 0)"
    else
        echo "$(tput setaf 1)$(tput setab 7).gitconfig Allready Contains all Settings $(tput sgr 0)"
    fi
}

# Mediatek source code server credentials configuration set up in .netrc file
setUp_netrc(){

    export PYTHONHTTPSVERIFY=0 &&  echo "$(tput setaf 1)$(tput setab 7) export PYTHONHTTPSVERIFY=0 $(tput sgr 0)"
    if [ -f $HOME/.netrc ];
    then 
	    echo "$(tput setaf 1)$(tput setab 7).netrc file  Allready preset at $HOME $(tput sgr 0)"
    else
	    cd $HOME
	    wget -nv  http://10.52.214.55/kivi_android/Sdk/repo_ga/netrc.tar.gz
	    tar -xvf netrc.tar.gz  && echo "$(tput setaf 1)$(tput setab 7).netrc file  Copied at $HOME $(tput sgr 0)"
	    rm -rf netrc.tar.gz
    fi

}


# GIT Tag checkout
repo_manifest_checkout(){
        cd $repo_workspace/.repo/manifests
        git checkout $build_tag
        cd $repo_workspace
        echo "$(tput setaf 1)$(tput setab 7) Manifest HEAD is attached to tag: $build_tag $(tput sgr 0)"
}


# Build Version Control
build_version(){
    cd $repo_workspace/.repo/manifests
    head_tag=$(git lola -1 | cut -d ',' -f2 | cut -d ':' -f2)	
    [[ ! $head_tag == *CW* ]] &&  head_tag=$( git lola -1 | cut -d " " -f2) # in case git tag is absent then we will collect comit Id
    echo "$head_tag"
}

clean_all(){
        repo_workspace=$1
        cd $repo_workspace && rm -rf out/ emmc_files/  && echo "Deleted out/ and emmc_files/ from $repo_workspace"
        # calling hmi clean fun.
       # clean_hmi $repo_workspace $2
}

clean_kivi(){
	package_cfg="$SCRIPT_DIR/components.txt"
        #$(awk -F "," '{ if( $2 ~ "/" ) print $2 ; }'  aosp_repo.csv > components_full.txt)
	path_prefix="out/soong/.intermediates"

	IFS=$'\n' read -d '' -r -a packages < $package_cfg
	#echo ${packages[2]}
	#echo ${packages[@]}

	package_total=$(wc -l < $package_cfg)
	for package_path in "${packages[@]}"
	{
           path_tmp="$path_prefix/$package_path"
           [[ -d $path_tmp ]] && rm -rf $path_tmp && echo "Deleting intermediates ..  $path_tmp"
	}
}

clean_hmi(){
        repo_workspace=$1
	package_cfg=$2
        echo "$(tput setaf 1) HMI APK Cleaning started"
	IFS=$'\n' read -d '' -r -a packages < $package_cfg
	for package_path in "${packages[@]}"
  	{
   	  echo "$(tput setaf 4) Cleaning APK :- $repo_workspace/$package_path"
          [[ -d $repo_workspace/$package_path ]] && cd $repo_workspace/$package_path && ./gradlew clean
	}
}

check_for_ko_files_update(){     #yocto build utils
    repo_workspace=$1
    target=$2
    target_ko_file_path="$repo_workspace/meta/meta-konfluence/recipes-core/runit/files"
    local_ko_files="$basepath/ko_files"  # considering inside basepath
    mkdir -p $local_ko_files/$target && cd $local_ko_files/$target &&  rm -rf *
    wget -nv -e robots=off -l1 -r -np -nH --reject="index.html*" http://$AOSP_KO_FILE_PATH/$target && cd kivi_android/ko_files/$target
    AOSP_ko_version=$(modinfo snd-avirt-ap-loopback.ko  | sed -n '5p' | awk '{print $2}')
    cd $target_ko_file_path
    yocto_ko_version=$(modinfo snd-avirt-ap-loopback.ko  | sed -n '5p' | awk '{print $2}')
    if [ "$AOSP_ko_version" = "$yocto_ko_version" ]; then
        echo "$(tput setaf 1)$(tput setab 7)Version are same .. *.ko files are Up To Date $(tput sgr 0)"
    else
        echo "$(tput setaf 1)$(tput setab 7)Version are Not same .. Need to updtae latest *.ko files from AOSP build $(tput sgr 0)"
        rm -rf snd-avirt-ap-loopback.ko snd-avirt-core.ko
        cp -v $local_ko_files/$target/kivi_android/ko_files/$target/*.ko $target_ko_file_path && chmod +x *.ko && echo "$(tput setaf 10)KO files updated $(tput sgr 0)" 
        # calling git push function
        push_ko_files_update $repo_workspace $target
    fi
}

push_ko_files_update(){
     repo_workspace=$1
     target=$2
     target_path="$repo_workspace/meta/meta-konfluence/"
     target_branch=$MP_branch
     [[ "$target" = "conti" ]] && target_branch=$Conti_branch
     cd $target_path
     git add .
     git commit -m "Updated latest *.ko files with AOSP $target build"
     git push BMS $target_branch
}

Build_No(){       #CW29DB03 / CW29DB03C / CW29DB03P
    target=$1
    type=$2
    oparation=$3
    AOSP_server=$(echo $FTP | awk -F ':' '{ print $1 }')
    Build_no=$(ssh $AOSP_server "cd /zen/kivi_android/Build_no;./build_no.sh $target $type $oparation;") 
    printf "$Build_no" 
} 

yocto_build_conf_setup(){
    repo_workspace=$1
    template1="TMPDIR $repo_workspace/build/tmp"
    template2="SSTATE_DIR $repo_workspace/build/../sstate-cache"

    cd $repo_workspace/build/conf
    ln -s ../../meta/meta-konfluence/conf/build.bblayers.conf bblayers.conf
    ln -s ../../meta/meta-konfluence/conf/build.local.conf local.conf 
    sed -i -r "`grep -nw "TMPDIR" sanity_info | awk -F":" '{print $1 }'`"s"#.*#$template1#g" sanity_info  && echo "modified TMPDIR"
    sed -i -r "`grep -nw "SSTATE_DIR" sanity_info | awk -F":" '{print $1 }'`"s"#.*#$template2#g" sanity_info && echo "modified SSTATE_DIR"
}

yocto_meta_layers_pull(){
    repo_workspace=$1
    branch=$2
    meta_layers=(meta-konfluence meta-kivi meta-binder meta-mediatek)

    cd $repo_workspace
    for layer in "${meta_layers[@]}"
    do
	cd $repo_workspace/meta/$layer && pwd
        git checkout $branch && git pull
    done
}

yocto_build_tag_checkout(){
    repo_workspace=$1
    branch=$2
	build_tag=$3
    meta_layers=(meta-konfluence meta-kivi)
    cd $repo_workspace
    for layer in "${meta_layers[@]}"
    do
	cd $repo_workspace/meta/$layer && pwd
        git checkout $branch && git pull
		git checkout $build_tag
    done
}

yocto_build_tag(){
    repo_workspace=$1
    target_branch=$2
    meta_layers=(meta-konfluence meta-kivi)
    build_no=$(Build_No $target yocto increment) && echo $build_no
    for layer in "${meta_layers[@]}"
    do
	cd $repo_workspace/meta/$layer && pwd
        git checkout $target_branch && git pull
		git tag $build_no
		git push origin $build_no
    done
}

copy_git01_repos(){
     repo_workspace=$1
     cd $repo_workspace && pwd
     wget -nv http://10.52.214.55/kivi_android/Sdk/git01_repos.tar.gz
     tar xzf git01_repos.tar.gz
     cd git01_repos && cp -r --parent * $repo_workspace
     cd $repo_workspace && rm -rf git01_repos.tar.gz git01_repos/
}

