#!/bin/bash

User_MSG="please provide target as argv1 & cutrent[based] build no :argv2 and target build no as :argv2[if not specified the it take latest]"
[ $# -lt 2 ] && echo -e $User_MSG && exit 1
target=$1
curr_ver=$2  # base build
target_ver=$3  # target build
SCRIPT_DIR=$(dirname $(readlink -f "$0"))
source $SCRIPT_DIR/build_utils.sh
[[ -z $target_ver ]] && target_verTmp=$(Build_No $target aosp read) && latest="true"
apache_path="/zen/kivi_android/Sdk"

cd $apache_path
#pending checking/validation
if [[ "$curr_ver" == "device" ]];then 
    curr_ver="$HOME/tmp/adb" && curr_verMd="adb" ;
else 
   curr_verMd=$(echo $curr_ver) 
   [[ ! -f $apache_path/$curr_ver/$curr_verMd.md5 ]] && echo "$USER@`hostname -i`:$apache_path/$target_ver/$target_ver.tar.gz" && exit 1;
fi
mkdir -p $SCRIPT_DIR/delta
diff $target_ver/$target_ver.md5 $curr_ver/$curr_verMd.md5 | awk -F ' ' '/^</{print $3}' >> $SCRIPT_DIR/$target_ver.diff

cd $target_ver  &&mkdir -p IMGtmp  # mount point for all partitions
readarray -t array <<< "$(grep -i ":manifest" $SCRIPT_DIR/$target_ver.diff)" &&  count=0  # file split on basis od partition
for line in $(cat $SCRIPT_DIR/$target_ver.diff); do
    if [[ "$line" == "${array[$count]}" ]]; then
        [[ ! "$count" == "0" ]] && cd  $apache_path/$target_ver && sudo umount IMGtmp/
        partition=$(echo $line | awk -F ':' '{print $1}')
	tar -xzf $target_ver.tar.gz emmc_files/$partition.img   # untar only partition.img
        simg2img ./emmc_files/$partition.img  $partition.raw.img   # conversion
        sudo mount -o loop $partition.raw.img IMGtmp/ && cd IMGtmp/  # mount
        [[ ! "$partition" == "vendor" ]] && cd $partition  # due vendor diffrent beheviour
        mkdir -p $SCRIPT_DIR/delta/$partition
        count=$((count+1))  # to move on next partition from  diff contents
    else
       cp -r --parents $line $SCRIPT_DIR/delta/$partition/  2> /dev/null || echo "$line" >> $SCRIPT_DIR/delta/$partition.err
    fi
done
   cd  $apache_path/$target_ver  # clearing temporary created data and mount partition
   sudo umount IMGtmp/ && rm -rf *.raw.img emmc_files/ IMGtmp/
   cd $SCRIPT_DIR && echo "$USER@`hostname -i`:$PWD/$target_ver.delta.tgz"   # to send full path of delta.tgz on clinet side.
   tar -czf  $target_ver.delta.tgz  delta/ && rm -rf delta/
   
   
   # delta avaible or not clint side.
