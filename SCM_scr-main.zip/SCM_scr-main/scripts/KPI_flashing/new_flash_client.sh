#!/bin/bash

##########################################################
# Author   : Amit Shinde
# Desc     : KPI Performnace flashing script
#pending testing at clinet side. (1st round of testing completed)
#############################################################

msg_USAGE="$0 <target> <WorkDir/device> <target-buid-no>
\n\t\t<target>         - arg1, target  'mediatek', 'conti', 'pana'
\n\t\t<WorkDir/device> -arg2,<workDir> - path where target specific build is present.
			    Ex-. at path /home/kpit/builds/ you have downloaded 21CW41DB05M.tar.gz and extracted.
			<device> - If you pass arg2 as device, then process will consider connected target(hw board) as workdir, and process accordingly.
 
\n\t\t<target-buid-no> - arg3[Optional], build no which you want flash, If not provided the it will take lastest build no."

[ $# -lt 2 ] && echo -e $msg_USAGE && exit 1

# check VPN connectivity.
ping -c1 10.52.214.55 &> /dev/null
[[ $? -eq 1 ]] && echo "No connectivity to 10.52.214.55 Please check VPN && run ssh-copy-id vivekk@10.52.214.55" && exit 1;

#variables initilizations
Build_server=vivekk@10.52.214.55
partition_arr="system vendor"
target=$1
[ -z $2 ] && workdir="$(readlink -f .)"
[[ $2 == 'device' ]] && device="true" ; 
[ ! -z $2 ] && [ -d $2 ] && workdir=$2
target_ver=$3
[[ -z $target_ver ]] && target_ver=$(ssh $Build_server "cd /zen/kivi_android/Build_no;./build_no.sh $target aosp raed;") && latest="true" # latest success Build No

# function to check connectivity for target.
check_connectivity_with_device(){
    ADB_PATH=$(which adb)
    ADB_OUT=`$ADB_PATH devices | awk 'NR>1 {print $1}'`       
    [[ -z "$ADB_OUT" ]] && echo "No device Found" && return 1;
    return 0;
}

# Function to make device read/write ready.
make_device_rw(){
    adb root && adb remount || return 1;
    echo "abd is aviable for read/write"
    return 0;
}

# Function to collect md5 drom target
pull_md5_from_device(){
    base_path=$1
    #adb shell commands, pending to make it dynamic.
     adb shell "mkdir tmp ;cd system ;pwd; 
     echo 'system:manifest'>>/tmp/adb.md5; find . -type f -print0 | sort -z | xargs -0 md5sum >>/tmp/adb.md5 ;cd ../vendor; pwd;
     echo 'vendor:manifest'>>/tmp/adb.md5 find . -type f -print0 | sort -z | xargs -0 md5sum >>/tmp/adb.md5;exit"
     cd $base_path && pwd
     sudo adb pull tmp/adb.md5 .
     [[ ! -f adb.md5 ]] && echo "adb pull failed " && return 1;
     echo "Pulled md5 file form adb device @ $PWD" && return 0;
}

# Function to push delta into target device
push_delta_into_device(){
   deltaDIR=$1 && cd $deltaDIR
   for partition in ${partition_arr} ; do
      echo "Push $partition delta to devices"
      cd $partition
      sudo adb push . $partition/    # need to validate with  -vr --parent
      cd ../
    done
    echo "please do reboot the hw"
}

#function to push delta into present build system.img and prepare flashing pkg.
push_delta_in_host_img(){
   workdir=$1
   cd $workdir/$current_ver && pwd
   mkdir -p tmp
   for partition in ${partition_arr} ; do
     echo " $partition "
     simg2img ./emmc_files/$partition.img  $partition.raw.img   # conversion
     sudo mount -o loop $partition.raw.img tmp/ && cd tmp/  # mount
     [[ ! "$partition" == "vendor" ]] && cd $partition
     sudo cp -r --parents $workdir/$target_ver/emmc_files/delta/$partition/*  .
	 cd $workdir/$current_ver && sudo umount tmp/
     mv  $partition.raw.img $workdir/$target_ver/emmc_files/$partition.img    # replaced modified with original *.img     
   done
}

# Function to connect build server and get the pkg scp path.
connect_to_server(){
    current_ver=$1
    target_ver=$2
    workDir=$3 #&& cd $workDir
    server_delta=$(ssh $Build_server "cd /home/vivekk/scripts/flashing;./server_delta_create.sh  $target $current_ver $target_ver;")
    scp -r $server_delta . 
    mkdir -p $workDir/$target_ver
    tar xzf $target_ver.tar.gz -C $workDir/$target_ver
}

#main
if [[ "$device" == "true" ]]; then
    workDir="$HOME/device" && mkdir -p $workDir 
	cd $workDir
    check_connectivity_with_device ;[[ $? == "1" ]] && echo "NO device Found" && exit 1;
    make_device_rw && [[ $? == "1" ]] && echo "Not able to set adb as read/write device" && exit 1;
    pull_md5_from_device $workDir && [[ $? == "1" ]] && exit 1;
    scp -r adb.md5 $Build_server:/home/vivekk/tmp/adb/ && current_ver="device"  
    connect_to_server $current_ver $target_ver $workDir
    push_delta_into_device $workDir/$target_ver/emmc_files/delta    # we only copy delta (for now)
else
   cd $workdir      
   current_ver=$(ls -d 21CW*DB* | tail -1 )  # current build no from path which provided bt user. (latest one)
   [[ ! -z $current_ver ]] && "No any build found in $workdir " && exit 1;
   connect_to_server $current_ver $target_ver $workdir
   push_delta_in_host_img $workdir 
   echo "Run 'sudo ./flashing.sh' from '$workdir/$target_ver/emmc_files/' to flash the hardware"

exit 0
