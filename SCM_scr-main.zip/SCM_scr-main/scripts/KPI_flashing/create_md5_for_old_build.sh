#!/bin/bash
# Author: Amit Shinde.
# Desc: Script to genrate md5 for previous week build 
#       just upadte the week No.

week="${1:-42}"
partition_arr="system vendor"
apache="/zen/kivi_android/Sdk" 

cd $apache &&  pwd
for dir in `ls -d 21CW$week*`;  do
        echo $dir
        cd $dir && path=$(pwd) && rm -rf *.md5 && echo "deleted *.md5 files "
        mkdir -p tmp 
        for partition in ${partition_arr} ; do
           tar -xvzf 21CW*.tar.gz emmc_files/$partition.img
	   simg2img ./emmc_files/$partition.img  $partition.raw.img && echo "Converted $partition"
	   sudo mount -o loop  $partition.raw.img tmp/
           cd tmp/ && echo "$partition:manifest" >> $path/$dir.md5
           [[ ! "$partition" == "vendor" ]] && cd $partition  # due vendor diffrent beheviour
           find . -type f -print0 | sort -z | xargs -0 md5sum >> $path/$dir.md5
           cd $path &&  sudo umount tmp 
        done
        rm -rf emmc_files/ tmp/  *.raw.img  && cd $apache
       echo "------------------------------------------------------------------------------"
 done
