#!/bin/bash

###########################################################################################
# Authore : Amit Shinde.
# Desc.   : Script will genrate diffrence delta detween current build and  target build.
#           script will return the scp path for delta pck.
#--------------------------------------------------------------------------------------------

msg_USAGE="$0 <target> <current-build-No> <target-buid-No>
\n\t\t<target>         - arg1, target  'mediatek', 'conti', 'pana'
\n\t\t<current-build-No> -arg2, Base build no, which you want to upadte with target build.			               
\n\t\t<target-buid-no> - arg3[Optional], build no which you want flash, If not provided the it will take lastest build no."

[ $# -lt 2 ] && echo -e $msg_USAGE && exit 1

target=$1
curr_ver=$2  # base build
target_ver=$3  # target build
SCRIPT_DIR=$(git rev-parse --show-toplevel)
source $SCRIPT_DIR/kDit_utils.sh
[[ -z $target_ver ]] && target_ver=$(Build_No $target aosp read) && latest="true"
apache_path="/zen/kivi_android/Sdk"

create_delta(){
    target_ver=$1
    diff_file="$2"
    cd $apache_path/$target_ver && mkdir -p IMGtmp  # mount point for all partitions
    readarray -t array <<< "$(grep -i ":manifest" $diff_file)" &&  count=0  # file split on basis on partition
    for line in $(cat $diff_file); do
    if [[ "$line" == "${array[$count]}" ]]; then
        [[ ! "$count" == "0" ]] && cd  $apache_path/$target_ver && sudo umount IMGtmp/
        partition=$(echo $line | awk -F ':' '{print $1}')
		tar -xzf $target_ver.tar.gz emmc_files/$partition.img   # untar only partition.img
        simg2img ./emmc_files/$partition.img  $partition.raw.img   # conversion
        sudo mount -o loop $partition.raw.img IMGtmp/ && cd IMGtmp/  # mount
        [[ ! "$partition" == "vendor" ]] && cd $partition  # due vendor diffrent beheviour
        mkdir -p $SCRIPT_DIR/delta/$partition
        count=$((count+1))  # to move on next partition from  diff contents
    else
       cp -r --parents $line $SCRIPT_DIR/delta/$partition/  2> /dev/null || echo "$line" >> $SCRIPT_DIR/delta/$partition.err
    fi
   done
   cd  $apache_path/$target_ver  # clearing temporary created data and mount partition
   sudo umount IMGtmp/ && rm -rf *.raw.img emmc_files/ IMGtmp/	 
} 

create_pkg(){
     target_ver=$1 && cd $apache_path/$target_ver
     [[ -z $2 ]] && delta_file="$apache_path/$target_ver/$target_ver.delta.tgz"
     delta_file="$2"
     # tar command to exclude system.img & vendor.img while untar -- pending
     tar xzf $target_ver.tar.gz 
     rm -rf emmc_files/system.img && rm -rf emmc_files/vendor.img    #this shoulb be avoid
     mv $delta_file emmc_files/ && tar czf $SCRIPT_DIR/$target.tar.gz emmc_files/
     rm -rf emmc_files/
}

cd $apache_path
if [[ "$curr_ver" == "device" ]];then 
    curr_ver="$HOME/tmp/adb" && curr_verMd="adb" ;
else 
   curr_verMd=$(echo $curr_ver); 
   [[ ! -f $apache_path/$curr_ver/$curr_verMd.md5 ]] && echo "$USER@`hostname -i`:$apache_path/$target_ver.tar.gz" && exit 0;
fi
last_success_build=$( Build_No $target aosp decrement) # 2nd last success build no
[ \( "$current_ver" == "$last_success_build"  -a "$latest" == "true" \) ] && create_pkg $target_ver

diff $target_ver/$target_ver.md5 $curr_ver/$curr_verMd.md5 | awk -F ' ' '/^</{print $3}' >> $SCRIPT_DIR/$target_ver.diff
mkdir -p $SCRIPT_DIR/delta/
create_delta $target_ver $SCRIPT_DIR/$target_ver.diff    #function call 
create_pkg $target_ver $SCRIPT_DIR/delta/                # function call
cd $SCRIPT_DIR && echo "$USER@`hostname -i`:$PWD/$target.tar.gz"   # to send full path of delta.tgz on clinet side.
rm -rf delta/
exit 0;
