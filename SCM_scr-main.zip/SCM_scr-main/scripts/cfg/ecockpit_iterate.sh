#!/bin/bash

module_file="${1:-ecockpit_modules.csv}"
exec_file=$2

cat $module_file |
while read line
do
  module=`echo $line| awk -F "," '{print $1}'`
  src_type=`echo $line| awk -F "," '{print $2}'`
  SCA=`echo $line| awk -F "," '{print $3}'`
  UT=`echo $line| awk -F "," '{print $4}'`
  FOSS=`echo $line| awk -F "," '{print $5}'`
  AOSP=`echo $line| awk -F "," '{print $6}'`
  Yocto=`echo $line| awk -F "," '{print $7}'`
  repo_path=`echo $line| awk -F "," '{print $8}'`
  repo_branch=`echo $line| awk -F "," '{print $9}'`

name=$(echo ${module// /_})
if [ ! -z $name ]; then
    echo "$name  :: $src_type" 
    if [ "$src_type" = "CPP" ] || [ "$src_type" = "C" ]; then
      cp -v /home/bms/tmp/reports/Gtest-ut.xml /kpit/reports/yocto/TEST-$name.xml
    elif [ "$src_type" = "Java" ]; then
      cp -v /home/bms/tmp/reports/TEST-ut.xml /kpit/reports/aosp/TEST-$name.xml
   fi
 fi
#  echo "$module" #: $src_type : $SCA : $UT : $FOSS : $AOSP : $Yocto : $repo_path: $repo_branch"
#  cat $exec_file
done
